import React, { useState } from 'react';
import {
  Star,
  ShoppingBag,
  Send,
  Plus,
  Minus,
  ShieldCheck,
  Heart,
  Flame,
  CheckCircle2,
  AlertCircle,
  Truck,
  Leaf,
  ChevronLeft,
  Sparkles,
  ArrowLeft,
  Check,
  ChefHat,
} from 'lucide-react';
import { PRODUCTS } from '../data/products';
import { TELEGRAM_BOT_URL } from '../data/config';
import { Product, SizeOption, PageView } from '../types';
import { useCart } from '../context/CartContext';
import { ProductCard } from '../components/common/ProductCard';

interface ProductDetailPageProps {
  productId: string;
  onNavigate: (page: PageView) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  productId,
  onNavigate,
}) => {
  const product = PRODUCTS.find((p) => p.id === productId) || PRODUCTS[0];
  const { addToCart, setIsCartDrawerOpen } = useCart();

  const [selectedSize, setSelectedSize] = useState<SizeOption>(product.sizes[0]);
  const [quantity, setQuantity] = useState(1);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [activeTab, setActiveTab] = useState<'story' | 'ingredients' | 'reviews'>('story');
  const [justAdded, setJustAdded] = useState(false);

  // When product changes, reset state
  React.useEffect(() => {
    setSelectedSize(product.sizes[0]);
    setQuantity(1);
    setSelectedImageIndex(0);
  }, [product.id]);

  const handleAddToCart = () => {
    addToCart(product, selectedSize, quantity);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  };

  const handleTelegramOrder = () => {
    const message = `سلام، قصد سفارش سریع این محصول از کارگاه خوشمزه‌ها را دارم:\n- نام محصول: ${product.name}\n- وزن/بسته‌بندی: ${selectedSize.label}\n- تعداد: ${quantity}\n- مبلغ تقریبی: ${(selectedSize.price * quantity).toLocaleString('fa-IR')} تومان`;
    const url = `${TELEGRAM_BOT_URL}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  // Recommendations: find pairing or other items
  const suggestedProducts = PRODUCTS.filter(
    (p) => p.id !== product.id && (product.suggestedPairingIds?.includes(p.id) || true)
  ).slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10 text-right space-y-12">
      {/* 1. Breadcrumbs */}
      <nav className="flex items-center gap-2 text-xs text-[#717c6e] flex-wrap">
        <button
          onClick={() => onNavigate({ type: 'home' })}
          className="hover:text-[#2c3d28] transition-colors cursor-pointer"
        >
          صفحه اصلی
        </button>
        <span>/</span>
        <button
          onClick={() => onNavigate({ type: 'products' })}
          className="hover:text-[#2c3d28] transition-colors cursor-pointer"
        >
          کاتالوگ محصولات
        </button>
        <span>/</span>
        <button
          onClick={() => onNavigate({ type: 'products', categorySlug: product.categorySlug })}
          className="hover:text-[#2c3d28] transition-colors cursor-pointer"
        >
          {product.category}
        </button>
        <span>/</span>
        <span className="font-semibold text-[#2c3d28] truncate">{product.name}</span>
      </nav>

      {/* 2. Main Product Layout (Matching Image 12 exactly) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left Column: Details & Purchase actions (in RTL layout, this is on the left) */}
        <div className="lg:col-span-6 space-y-6 order-2 lg:order-1">
          {/* Top Pill & Ratings */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            {product.badge && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#faecee] text-[#8b2332] text-xs font-bold border border-[#f3d3d7]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{product.badge}</span>
              </span>
            )}

            <div className="flex items-center gap-1.5 text-xs text-[#6e7769]">
              <span className="font-bold text-sm text-[#232724]">{product.rating}</span>
              <div className="flex items-center text-[#c29633]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-current" />
                ))}
              </div>
              <span className="text-[#889283]">({product.reviewsCount} نظر خانگی)</span>
            </div>
          </div>

          {/* Product Title & Subtitle */}
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-[#232724] leading-tight">
              {product.name}
            </h1>
            <p className="text-xs sm:text-sm text-[#5f6b5b] mt-3 leading-relaxed">
              {product.shortDescription}
            </p>
          </div>

          {/* Stock Availability status */}
          <div className="flex items-center gap-2 text-xs font-semibold text-[#2c3d28] bg-[#f0f6ec] p-2.5 rounded-xl border border-[#dce8d6]">
            <span className="w-2.5 h-2.5 rounded-full bg-[#3d7a28] animate-pulse shrink-0" />
            <span>{product.stockStatusText}</span>
          </div>

          {/* Price & Packaging Selector Box */}
          <div className="bg-[#fbf9f5] p-5 rounded-2xl border border-[#ebe4d6] space-y-5">
            {/* Price display */}
            <div className="flex items-center justify-between border-b border-[#ece5d8] pb-3">
              <span className="text-xs text-[#717c6e] font-medium">بهای محصول:</span>
              <div className="flex items-center gap-1.5">
                <span className="text-2xl sm:text-3xl font-black text-[#232724]">
                  {(selectedSize.price * quantity).toLocaleString('fa-IR')}
                </span>
                <span className="text-xs font-semibold text-[#667262]">تومان</span>
              </div>
            </div>

            {/* Size & Weight selector */}
            <div className="space-y-2.5">
              <label className="block text-xs font-bold text-[#353f32]">
                انتخاب وزن و نوع بسته‌بندی:
                <span className="font-normal text-[#717c6e] mr-1.5">
                  ظرف شیشه‌ای استاندارد با پلمپ موم و کنف
                </span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {product.sizes.map((size) => {
                  const isSelected = selectedSize.label === size.label;
                  return (
                    <button
                      key={size.label}
                      onClick={() => setSelectedSize(size)}
                      className={`p-3 rounded-xl text-right border transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-[#2c3d28] text-white border-[#2c3d28] shadow-sm'
                          : 'bg-white text-[#232724] border-[#ded5c5] hover:border-[#2c3d28]/40'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="font-extrabold text-sm">{size.label}</span>
                        {size.badge && (
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              isSelected
                                ? 'bg-white/20 text-white'
                                : 'bg-[#faecee] text-[#8b2332]'
                            }`}
                          >
                            {size.badge}
                          </span>
                        )}
                      </div>
                      <span
                        className={`text-[11px] mt-1 ${
                          isSelected ? 'text-[#e0ecd6]' : 'text-[#717c6e]'
                        }`}
                      >
                        {size.description || `${size.price.toLocaleString('fa-IR')} تومان`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity Stepper & Add to Cart button */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              {/* Stepper */}
              <div className="flex items-center justify-between bg-white border border-[#ded5c5] rounded-xl p-1.5 w-full sm:w-32 shrink-0">
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-8 h-8 rounded-lg bg-[#f5f1e8] hover:bg-[#eadecc] text-[#2c3d28] flex items-center justify-center transition-colors cursor-pointer"
                  title="افزایش تعداد"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <span className="font-extrabold text-sm text-[#232724] w-8 text-center">
                  {quantity.toLocaleString('fa-IR')}
                </span>
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 rounded-lg bg-[#f5f1e8] hover:bg-[#eadecc] text-[#2c3d28] flex items-center justify-center transition-colors cursor-pointer"
                  title="کاهش تعداد"
                >
                  <Minus className="w-4 h-4" />
                </button>
              </div>

              {/* Add to Cart button */}
              <button
                onClick={handleAddToCart}
                className={`flex-1 w-full py-3.5 px-6 rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  justAdded
                    ? 'bg-[#3b5334] text-white'
                    : 'bg-[#2c3d28] hover:bg-[#384e33] text-white'
                }`}
              >
                {justAdded ? (
                  <>
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>به سبد خرید افزوده شد!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>افزودن به سبد خرید</span>
                  </>
                )}
              </button>
            </div>

            {/* Secondary Direct Order via Telegram Bot */}
            <button
              onClick={handleTelegramOrder}
              className="w-full py-3 rounded-xl border border-[#ded5c5] bg-white hover:bg-[#f3ede3] text-[#2c3d28] font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-[#8b2332]" />
              <span>سفارش مستقیم و سریع از طریق بات پیام‌رسان کارگاه</span>
            </button>
          </div>

          {/* 3 Value Badges (Image 12) */}
          <div className="grid grid-cols-3 gap-2.5 pt-2 text-center">
            <div className="bg-white p-3 rounded-xl border border-[#ebe4d6] flex flex-col items-center">
              <CheckCircle2 className="w-4 h-4 text-[#3d5930] mb-1" />
              <span className="font-bold text-[11px] text-[#232724]">انار ملس ساوه</span>
              <span className="text-[10px] text-[#717c6e]">دست‌چین بدون دانه‌های تلخ</span>
            </div>

            <div className="bg-white p-3 rounded-xl border border-[#ebe4d6] flex flex-col items-center">
              <Leaf className="w-4 h-4 text-[#8b2332] mb-1" />
              <span className="font-bold text-[11px] text-[#232724]">بدون شکر و نشاسته</span>
              <span className="text-[10px] text-[#717c6e]">غلظت طبیعی ۱۰۰٪ خالص</span>
            </div>

            <div className="bg-white p-3 rounded-xl border border-[#ebe4d6] flex flex-col items-center">
              <Truck className="w-4 h-4 text-[#3d5930] mb-1" />
              <span className="font-bold text-[11px] text-[#232724]">بسته‌بندی ضربه‌گیر</span>
              <span className="text-[10px] text-[#717c6e]">ارسال امن با شیشه مقاوم</span>
            </div>
          </div>
        </div>

        {/* Right Column: Photo Gallery & Identity Passport (Image 12) */}
        <div className="lg:col-span-6 space-y-4 order-1 lg:order-2">
          {/* Main Photo with floating badges */}
          <div className="relative aspect-square w-full rounded-3xl overflow-hidden border-2 border-[#e8e2d4] bg-[#f5f1e8] shadow-sm">
            <img
              src={product.images[selectedImageIndex] || product.images[0]}
              alt={product.name}
              className="w-full h-full object-cover"
            />

            {/* Top Right Badges */}
            <div className="absolute top-3.5 right-3.5 flex flex-col gap-2">
              <span className="bg-white/95 backdrop-blur-xs text-[#2c3d28] text-xs font-bold px-3 py-1.5 rounded-full shadow-xs flex items-center gap-1.5 border border-[#e4dfd3]">
                <ShieldCheck className="w-4 h-4 text-[#3b5334]" />
                ۱۰۰٪ خانگی و طبیعی
              </span>

              <span className="bg-white/95 backdrop-blur-xs text-[#8b2332] text-xs font-bold px-3 py-1.5 rounded-full shadow-xs flex items-center gap-1.5 border border-[#e4dfd3]">
                <Heart className="w-4 h-4 fill-current" />
                بدون مواد نگه‌دارنده
              </span>
            </div>

            {/* Bottom Left Badge: Copper Kettle */}
            <div className="absolute bottom-3.5 left-3.5">
              <span className="bg-[#2c3d28]/90 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-xs flex items-center gap-1.5 backdrop-blur-xs">
                <Flame className="w-4 h-4 text-[#e0ecd6]" />
                پخت آرام در دیگ مسی
              </span>
            </div>
          </div>

          {/* Thumbnails Gallery */}
          {product.images.length > 1 && (
            <div className="flex items-center gap-3">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-20 h-20 rounded-2xl overflow-hidden border-2 transition-all cursor-pointer ${
                    selectedImageIndex === idx
                      ? 'border-[#2c3d28] scale-105 shadow-xs'
                      : 'border-[#e4ded2] opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Passport / Certificate Box: "شناسنامه دست‌پخت و مبدا پخت" (Image 12) */}
          <div className="bg-[#fcfbf7] p-5 rounded-2xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-[#eee8dc] pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-[#2c3d28] text-white flex items-center justify-center">
                  <ChefHat className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-[#232724]">
                    شناسنامه دست‌پخت و مبدأ پخت
                  </h4>
                  <span className="text-[10px] text-[#717c6e]">
                    دست‌رنج باغداران بومی و کدبانوهای کارگاه خوشمزه‌ها
                  </span>
                </div>
              </div>

              <span className="text-[11px] font-mono font-bold bg-[#ede6d8] text-[#2c3d28] px-2 py-0.5 rounded">
                کد اصالت: {product.craftCode}
              </span>
            </div>

            {/* 4 Attributes Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-center">
              <div className="bg-white p-2 rounded-xl border border-[#ebe4d6]">
                <span className="text-[10px] text-[#717c6e] block">خاستگاه میوه:</span>
                <span className="text-[11px] font-bold text-[#232724] mt-0.5 block">
                  {product.origin}
                </span>
              </div>

              <div className="bg-white p-2 rounded-xl border border-[#ebe4d6]">
                <span className="text-[10px] text-[#717c6e] block">طبع و مزاج:</span>
                <span className="text-[11px] font-bold text-[#232724] mt-0.5 block">
                  {product.nature}
                </span>
              </div>

              <div className="bg-white p-2 rounded-xl border border-[#ebe4d6]">
                <span className="text-[10px] text-[#717c6e] block">زمان پخت:</span>
                <span className="text-[11px] font-bold text-[#232724] mt-0.5 block">
                  {product.cookTime}
                </span>
              </div>

              <div className="bg-white p-2 rounded-xl border border-[#ebe4d6]">
                <span className="text-[10px] text-[#717c6e] block">ماندگاری طبیعی:</span>
                <span className="text-[11px] font-bold text-[#232724] mt-0.5 block">
                  {product.shelfLife}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Detailed Tabs Section (Matching Image 12) */}
      <div className="bg-white rounded-3xl border border-[#ebe4d6] overflow-hidden shadow-xs">
        {/* Tabs Bar */}
        <div className="flex items-center gap-4 border-b border-[#eee8de] px-6 pt-4 bg-[#faf8f4] overflow-x-auto">
          <button
            onClick={() => setActiveTab('story')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'story'
                ? 'border-[#2c3d28] text-[#2c3d28]'
                : 'border-transparent text-[#717c6e] hover:text-[#232724]'
            }`}
          >
            داستان پخت و طعم
          </button>

          <button
            onClick={() => setActiveTab('ingredients')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'ingredients'
                ? 'border-[#2c3d28] text-[#2c3d28]'
                : 'border-transparent text-[#717c6e] hover:text-[#232724]'
            }`}
          >
            مواد اولیه و خواص
          </button>

          <button
            onClick={() => setActiveTab('reviews')}
            className={`pb-3 text-xs sm:text-sm font-bold border-b-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'reviews'
                ? 'border-[#2c3d28] text-[#2c3d28]'
                : 'border-transparent text-[#717c6e] hover:text-[#232724]'
            }`}
          >
            نظرات سفره‌داران ({product.reviewsCount})
          </button>
        </div>

        {/* Tab 1: داستان پخت و طعم + راهنمای نگهداری خانگی (Image 12) */}
        {activeTab === 'story' && (
          <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Story text */}
            <div className="lg:col-span-8 space-y-4">
              <h3 className="text-lg font-bold text-[#232724]">
                راز رنگ تیره و قوام شاهانه؛ حرارت صبورانه هیزم و مس
              </h3>
              <p className="text-xs sm:text-sm text-[#556052] leading-relaxed">
                {product.fullDescription}
              </p>
              {product.storyDescription && (
                <p className="text-xs sm:text-sm text-[#556052] leading-relaxed">
                  {product.storyDescription}
                </p>
              )}
            </div>

            {/* Storage guide box */}
            <div className="lg:col-span-4 bg-[#fbf9f5] p-5 rounded-2xl border border-[#ebe4d6] space-y-3">
              <h4 className="font-extrabold text-xs sm:text-sm text-[#232724] pb-2 border-b border-[#eee8dc]">
                راهنمای نگهداری خانگی:
              </h4>
              <ul className="space-y-2 text-xs text-[#556052]">
                {(product.storageAdvice || [
                  'همیشه از قاشق کاملاً خشک و تمیز استفاده شود.',
                  'پس از باز کردن پلمپ، در یخچال یا بستوی خنک نگهداری کنید.',
                  'به دلیل فقدان مواد شیمیایی، تغییر غلظت در سرما طبیعی است.',
                ]).map((advice, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#3b5334] shrink-0 mt-0.5" />
                    <span>{advice}</span>
                  </li>
                ))}
              </ul>
              <div className="pt-2 text-[11px] font-bold text-[#8b2332] text-center">
                «طعم یادآور مطبخ مادربزرگ‌های کویری»
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: مواد اولیه و خواص */}
        {activeTab === 'ingredients' && (
          <div className="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <h3 className="font-bold text-base text-[#232724]">ترکیبات و مواد تشکیل‌دهنده:</h3>
              <ul className="space-y-2 text-xs sm:text-sm text-[#556052]">
                {product.ingredients?.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <Leaf className="w-4 h-4 text-[#3b5334] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-3">
              <h3 className="font-bold text-base text-[#232724]">خواص سلامتی و مزاج:</h3>
              <ul className="space-y-2 text-xs sm:text-sm text-[#556052]">
                {product.properties?.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-[#8b2332] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* Tab 3: نظرات سفره‌داران */}
        {activeTab === 'reviews' && (
          <div className="p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-[#232724]">تجربه خریداران این دست‌پخت</h3>
              <span className="text-xs text-[#717c6e]">میانگین رضایت: ۹۸٪</span>
            </div>

            <div className="space-y-4">
              <div className="bg-[#fbf9f4] p-4 rounded-2xl border border-[#ebe4d6] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#232724]">زهرا م. (تهران)</span>
                  <span className="text-[#889283]">۳ روز پیش</span>
                </div>
                <div className="flex text-[#c29633]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-current" />
                  ))}
                </div>
                <p className="text-xs text-[#556052] leading-relaxed">
                  غلظت و طعمش واقعاً بی‌نظیره! من برای فسنجان استفاده کردم، قشنگ رنگ گردو رو سیاه و ملس
                  کرد بدون اینکه سرسوزنی ترشی زننده داشته باشه. دقیقاً مثل رب‌هایی که مادربزرگم تو یزد
                  درست می‌کرد.
                </p>
              </div>

              <div className="bg-[#fbf9f4] p-4 rounded-2xl border border-[#ebe4d6] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-[#232724]">علیرضا ک. (اصفهان)</span>
                  <span className="text-[#889283]">هفته گذشته</span>
                </div>
                <div className="flex text-[#c29633]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-current" />
                  ))}
                </div>
                <p className="text-xs text-[#556052] leading-relaxed">
                  بسته‌بندی ضربه‌گیر عالی بود، با پلمپ موم و نخ کنفی خیلی حس اصالت و احترام به مشتری
                  داشت. حتماً دوباره سفارش میدم.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 4. Recommendations Carousel / Grid (Matching Image 12) */}
      <section className="space-y-6 pt-6 border-t border-[#ece5d8]">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#8b2332]" />
              <h2 className="text-xl sm:text-2xl font-black text-[#232724]">
                چاشنی‌ها و نوبارانه‌های پیشنهادی
              </h2>
            </div>
            <p className="text-xs text-[#717c6e]">
              سازگار با طعم {product.name} بر سر سفره‌های گرم ایرانی
            </p>
          </div>

          <button
            onClick={() => onNavigate({ type: 'products' })}
            className="text-xs font-bold text-[#2c3d28] hover:text-[#8b2332] flex items-center gap-1 cursor-pointer"
          >
            <span>مشاهده تمام چاشنی‌های کارگاه</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {suggestedProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onNavigate={(id) => onNavigate({ type: 'product-detail', productId: id })}
            />
          ))}
        </div>
      </section>
    </div>
  );
};
