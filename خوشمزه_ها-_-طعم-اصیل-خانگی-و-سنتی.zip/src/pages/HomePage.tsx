import React from 'react';
import {
  ArrowLeft,
  Phone,
  Sparkles,
  ShieldCheck,
  Heart,
  Truck,
  Flame,
  Leaf,
  CheckCircle2,
  Package,
  Calendar,
  ChefHat,
  ChevronLeft,
} from 'lucide-react';
import { ProductCard } from '../components/common/ProductCard';
import { PRODUCTS, CATEGORIES } from '../data/products';
import { SITE_CONFIG } from '../data/config';
import { PageView } from '../types';

interface HomePageProps {
  onNavigate: (page: PageView) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const featuredProducts = PRODUCTS.slice(0, 4);
  const seasonalProducts = PRODUCTS.filter((p) => p.isSeasonal);

  return (
    <div className="space-y-16 sm:space-y-24 text-right">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#f7f3eb] via-[#faf7f0] to-white pt-8 pb-14 sm:py-16 border-b border-[#eee7da]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
            {/* Right Column: Hero Copy */}
            <div className="lg:col-span-7 space-y-6">
              {/* Pill badge */}
              <div className="inline-flex items-center gap-2 bg-[#eae3d5] text-[#2c3d28] text-xs font-semibold px-3.5 py-1.5 rounded-full border border-[#ded5c5]">
                <span className="w-2 h-2 rounded-full bg-[#8b2332] animate-pulse" />
                <span>روایت یک عشق؛ از مطبخ تجریش تا سفره‌های یک ایرانی</span>
              </div>

              {/* Main Headline */}
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#232724] leading-tight sm:leading-tight">
                طعم اصیل خاطرات مادر؛
                <span className="text-[#8b2332] block mt-1.5 sm:mt-2">
                  عطر سبزی تازه و چاشنی‌های دست‌ساز
                </span>
              </h1>

              {/* Lead Paragraph */}
              <p className="text-sm sm:text-base text-[#556052] leading-relaxed max-w-2xl">
                ما در کارگاه و مطبخ سنتی <span className="font-bold text-[#2c3d28]">«خوشمزه‌ها»</span>،
                رب‌های ملس هیزمی، ترشی‌های هفت‌بیجار جاافتاده، آبغوره‌های دست‌افشار و سبزیجات تازه
                شسته و سرخ‌شده را با رعایت کامل اصول بهداشتی و بدون سرسوزنی افزودنی شیمیایی به دست
                سفره‌های گرم شما می‌رسانیم.
              </p>

              {/* Value props bullets */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1 text-xs font-semibold text-[#2c3d28]">
                <div className="flex items-center gap-2 bg-white/80 p-2.5 rounded-xl border border-[#ebe4d6]">
                  <Leaf className="w-4 h-4 text-[#4a6b35] shrink-0" />
                  <span>۱۰۰٪ خانگی و طبیعی</span>
                </div>
                <div className="flex items-center gap-2 bg-white/80 p-2.5 rounded-xl border border-[#ebe4d6]">
                  <Flame className="w-4 h-4 text-[#8b2332] shrink-0" />
                  <span>پخت آرام در پاتیل مس</span>
                </div>
                <div className="flex items-center gap-2 bg-white/80 p-2.5 rounded-xl border border-[#ebe4d6] col-span-2 sm:col-span-1">
                  <Truck className="w-4 h-4 text-[#4a6b35] shrink-0" />
                  <span>ارسال ایمن و ضدضربه</span>
                </div>
              </div>

              {/* Hero CTA Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-3">
                <button
                  onClick={() => onNavigate({ type: 'products' })}
                  className="px-6 py-3.5 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-full font-bold text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span>مشاهده و خرید محصولات خانگی</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onNavigate({ type: 'seasonal' })}
                  className="px-5 py-3.5 bg-white border border-[#cfc5b3] text-[#2c3d28] hover:bg-[#f2ede4] rounded-full font-semibold text-sm transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4 text-[#8b2332]" />
                  <span>نوبارانه‌های این فصل</span>
                </button>

                <a
                  href={`tel:${SITE_CONFIG.phone}`}
                  className="px-4 py-3.5 text-[#556052] hover:text-[#8b2332] text-xs font-medium flex items-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>مشاوره تلفنی خرید</span>
                </a>
              </div>
            </div>

            {/* Left Column: Visual Composition with Mother photo & Jars */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Main Workshop Visual */}
                <div className="relative rounded-3xl overflow-hidden border-4 border-white shadow-xl bg-[#eadecc]">
                  <img
                    src="/src/assets/images/workshop_mothers.jpg"
                    alt="بانوان کارگاه خانگی خوشمزه‌ها"
                    className="w-full h-[360px] sm:h-[420px] object-cover"
                  />
                  {/* Subtle Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                  {/* Badge: Lorestan Doroud */}
                  <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-md p-3 rounded-2xl border border-[#ebe4d6] shadow-sm flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-[#2c3d28] text-white flex items-center justify-center">
                      <ChefHat className="w-5 h-5" />
                    </div>
                    <div className="text-right">
                      <span className="font-extrabold text-xs text-[#232724] block">
                        مطبخ مرکزی مادرانه
                      </span>
                      <span className="text-[11px] text-[#697464]">لرستان، دورود</span>
                    </div>
                  </div>

                  {/* Badge: Pure Aroma */}
                  <div className="absolute top-4 left-4 bg-[#8b2332] text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-sm">
                    عطر اصیل دست‌پخت
                  </div>
                </div>

                {/* Floating Jar Showcase Card */}
                <div
                  onClick={() => onNavigate({ type: 'product-detail', productId: 'rob-anar-sonnati' })}
                  className="absolute -bottom-6 -left-3 sm:-left-6 bg-white p-3 rounded-2xl border border-[#e4ded2] shadow-lg flex items-center gap-3 cursor-pointer hover:scale-105 transition-transform max-w-[240px]"
                >
                  <img
                    src="/src/assets/images/pomegranate_molasses.jpg"
                    alt="رب انار ملس دست‌ساز"
                    className="w-14 h-14 rounded-xl object-cover shrink-0 border border-[#eee8de]"
                  />
                  <div className="text-right min-w-0">
                    <span className="text-[10px] text-[#8b2332] font-bold block">
                      پرفروش‌ترین نوبارانه
                    </span>
                    <h4 className="text-xs font-bold text-[#232724] truncate">
                      رب انار ملس دست‌ساز
                    </h4>
                    <span className="text-[11px] font-extrabold text-[#2c3d28]">
                      ۱۳۵,۰۰۰ تومان
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Key Stats Strip (from Image 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 -mt-8 sm:-mt-12 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 bg-white p-4 sm:p-6 rounded-3xl border border-[#e8e2d4] shadow-sm text-center">
          <div className="p-3 border-l border-[#f0ebd0] last:border-0">
            <span className="block font-black text-2xl sm:text-3xl text-[#2c3d28]">۸ سال</span>
            <span className="text-xs text-[#6e7769] font-medium mt-1 block">پخت و پاکسازی اصیل</span>
          </div>

          <div className="p-3 border-l border-[#f0ebd0] last:border-0">
            <span className="block font-black text-2xl sm:text-3xl text-[#8b2332]">+۲۶</span>
            <span className="text-xs text-[#6e7769] font-medium mt-1 block">بانوی هنرمند محلی</span>
          </div>

          <div className="p-3 border-l border-[#f0ebd0] last:border-0">
            <span className="block font-black text-2xl sm:text-3xl text-[#2c3d28]">۱۰۰</span>
            <span className="text-xs text-[#6e7769] font-medium mt-1 block">محصول پخت خانگی</span>
          </div>

          <div className="p-3">
            <span className="block font-black text-2xl sm:text-3xl text-[#587532]">۱۰۰٪</span>
            <span className="text-xs text-[#6e7769] font-medium mt-1 block">تضمین سلامت و طعم</span>
          </div>
        </div>
      </section>

      {/* 3. Categories Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold text-[#8b2332] block mb-1">
              مجموعه دسته‌بندی‌های خوشمزه‌ها
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
              سفره رنگارنگ خوراکی‌های ناب محلی
            </h2>
          </div>
          <button
            onClick={() => onNavigate({ type: 'categories' })}
            className="text-xs sm:text-sm font-bold text-[#2c3d28] hover:text-[#8b2332] flex items-center gap-1 transition-colors self-start sm:self-auto cursor-pointer"
          >
            <span>مشاهده همه دسته‌بندی‌ها</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onNavigate({ type: 'products', categorySlug: cat.slug })}
              className="group bg-white rounded-2xl border border-[#ebe4d6] overflow-hidden hover:shadow-md hover:border-[#2c3d28]/30 transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              <div className="relative aspect-4/3 w-full bg-[#f6f2ea] overflow-hidden">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/15 group-hover:bg-black/5 transition-colors" />
                <span className="absolute bottom-2.5 right-2.5 bg-white/90 text-[#2c3d28] text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
                  {cat.productCount} محصول
                </span>
              </div>

              <div className="p-4 text-right flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-sm text-[#232724] group-hover:text-[#8b2332] transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-[11px] text-[#717c6e] mt-1 line-clamp-2 leading-relaxed">
                    {cat.tagline}
                  </p>
                </div>
                <div className="mt-3 pt-2 border-t border-[#f2ede4] flex items-center justify-between text-xs text-[#2c3d28] font-semibold">
                  <span>مشاهده محصولات</span>
                  <ChevronLeft className="w-3.5 h-3.5 group-hover:translate-x-[-3px] transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Seasonal Products Banner & Grid (محصولات این فصل) */}
      <section className="bg-[#f5f1e8] py-14 border-y border-[#e2dbce]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e8e0d1] text-[#8b2332] text-xs font-bold mb-2">
                <Leaf className="w-3.5 h-3.5" />
                <span>احترام به چرخه طبیعی فصول</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
                نوبارانه‌ها و طعم‌های محبوب این فصل
              </h2>
              <p className="text-xs sm:text-sm text-[#5f695b] mt-1 max-w-xl">
                میوه‌ها و سبزیجاتی که تازه از باغ‌های ساوه، تاکستان‌ها و دشت‌های حاصلخیز لرستان چیده شده‌اند.
              </p>
            </div>

            <button
              onClick={() => onNavigate({ type: 'seasonal' })}
              className="px-4 py-2 bg-white border border-[#d6ccbc] text-[#2c3d28] hover:bg-[#2c3d28] hover:text-white rounded-full text-xs font-bold transition-all flex items-center gap-1.5 self-start cursor-pointer shadow-xs"
            >
              <span>مشاهده پرونده فصلی</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {seasonalProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onNavigate={(id) => onNavigate({ type: 'product-detail', productId: id })}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 5. Featured / All Products Section (همان کارتهای موجود پروژه) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold text-[#8b2332] block mb-1">
              پیشنهادات خاص مطبخ خوشمزه‌ها
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
              چاشنی‌ها و نوبارانه‌های کارگاه
            </h2>
          </div>
          <button
            onClick={() => onNavigate({ type: 'products' })}
            className="text-xs sm:text-sm font-bold text-[#2c3d28] hover:text-[#8b2332] flex items-center gap-1 transition-colors self-start sm:self-auto cursor-pointer"
          >
            <span>ورود به کاتالوگ جامع محصولات ({PRODUCTS.length} قلم)</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onNavigate={(id) => onNavigate({ type: 'product-detail', productId: id })}
            />
          ))}
        </div>
      </section>

      {/* 6. Four Core Principles (سوگندنامه طعم و سلامت از Image 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold text-[#8b2332] block mb-1">سوگندنامه طعم و سلامت</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
            چهار اصل استوار که هرگز از آن کوتاه نمی‌آییم
          </h2>
          <p className="text-xs sm:text-sm text-[#677263] mt-2">
            بدون ادعاهای بزرگ‌نمایی‌شده صنعتی؛ آنچه در شیشه‌های ماست حاصل راستی دستان و وجدان کاری ماست.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Principle 1 */}
          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#f0ebd0] text-[#2c3d28] flex items-center justify-center mb-4">
                <ShieldCheck className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                ۱۰۰٪ سلامت‌محور و بدون نگه‌دارنده
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                هیچ نوع رنگ، بنزوات سدیم، اسانس شباهت طعم یا ماده قوام‌دهنده در مطبخ وجود ندارد.
                ماندگاری تنها با سرکه و جوشاندن اصولی پدید می‌آید.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#4e6b39] pt-4 mt-2 border-t border-[#f3eee4]">
              ضمانت خلوص غذا
            </span>
          </div>

          {/* Principle 2 */}
          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#faecee] text-[#8b2332] flex items-center justify-center mb-4">
                <Heart className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                دست‌رنج بانوان و احیای مهارت‌ها
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                کارگاه خوشمزه‌ها بستر اشتغال پایدار و شرافتمندانه برای مادران سرپرست خانوار و بانوان صاحب
                تجربه است تا هنر دست‌شان ارزش واقعی بیابد.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#8b2332] pt-4 mt-2 border-t border-[#f3eee4]">
              اشتغال محلی و توانمندسازی
            </span>
          </div>

          {/* Principle 3 */}
          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#eef3ea] text-[#3d5930] flex items-center justify-center mb-4">
                <Package className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                شفافیت و شناسنامه برای هر شیشه
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                روی برچسب هر شیشه، نام مبدأ میوه یا سبزی (مثلاً انار ساوه، سیر طارم) و تاریخ دقیق پخت به
                صورت خوانا و شفاف ثبت شده است.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#3d5930] pt-4 mt-2 border-t border-[#f3eee4]">
              شناسنامه و طبع خوراک
            </span>
          </div>

          {/* Principle 4 */}
          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#f2efe8] text-[#5c6856] flex items-center justify-center mb-4">
                <ChefHat className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                بهداشت مدرن با طعم دست‌پخت مادر
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                پایبندی به مقررات بهداشتی و آزمایشگاه مواد غذایی در عین حفظ سنت‌ها؛ استریل شیشه‌ها و لباس
                کار استاندارد دوشادوش مهربانی مطبخ.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#5c6856] pt-4 mt-2 border-t border-[#f3eee4]">
              استاندارد و نظارت سختگیرانه
            </span>
          </div>
        </div>
      </section>

      {/* 7. Services Teaser (خدمات آماده‌سازی سبزی و شیوه‌نامه بسته‌بندی) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: خدمات آماده‌سازی سبزی */}
          <div className="bg-gradient-to-br from-[#f8f5ee] to-[#ede7db] p-6 sm:p-8 rounded-3xl border border-[#e0d7c7] flex flex-col justify-between text-right">
            <div className="space-y-3">
              <span className="text-xs font-bold text-[#3d562f] bg-[#e1dacb] px-3 py-1 rounded-full inline-block">
                پاک‌کرده، شسته و سرخ‌شده
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-[#232724]">
                خدمات آماده‌سازی سبزیجات اصیل
              </h3>
              <p className="text-xs sm:text-sm text-[#586454] leading-relaxed">
                از شستشوی سه‌مرحله‌ای با آب سرد روان تا خردکردن ریز یکدست و سرخ‌کردن با روغن کنجد در
                پاتیل‌های مسی با شعله بسیار ملایم.
              </p>
            </div>
            <div className="pt-6">
              <button
                onClick={() => onNavigate({ type: 'services' })}
                className="px-5 py-2.5 bg-[#2c3d28] text-white hover:bg-[#384e33] rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>مشاهده خدمات آماده‌سازی سبزی</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Card 2: بسته‌بندی و ارسال */}
          <div className="bg-gradient-to-br from-[#f5ede7] to-[#e8ded7] p-6 sm:p-8 rounded-3xl border border-[#ded1c8] flex flex-col justify-between text-right">
            <div className="space-y-3">
              <span className="text-xs font-bold text-[#8b2332] bg-[#f0e2dc] px-3 py-1 rounded-full inline-block">
                ایمن، استریل و بدون شکستگی
              </span>
              <h3 className="text-xl sm:text-2xl font-extrabold text-[#232724]">
                شیوه‌نامه بسته‌بندی و ارسال خنک
              </h3>
              <p className="text-xs sm:text-sm text-[#586454] leading-relaxed">
                ظروف شیشه‌ای پلمپ‌شده با موم و نخ کنفی، بسته‌بندی ضربه‌گیر چندلایه حبابی و کارتن‌های
                کرافت مقاوم به همراه تضمین سلامت کامل بار تا مقصد.
              </p>
            </div>
            <div className="pt-6">
              <button
                onClick={() => onNavigate({ type: 'packaging' })}
                className="px-5 py-2.5 bg-[#8b2332] text-white hover:bg-[#9e2d3d] rounded-full text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <span>مشاهده شیوه‌نامه بسته‌بندی</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Call to Action Banner (from Image 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="rounded-3xl bg-[#283824] text-white p-8 sm:p-12 relative overflow-hidden text-center shadow-lg border border-[#374932]">
          {/* Subtle Organic Background Details */}
          <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-white/5 blur-2xl pointer-events-none" />
          <div className="absolute -bottom-12 -right-12 w-48 h-48 rounded-full bg-[#8b2332]/20 blur-2xl pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto space-y-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-[#d0e2c8] text-xs font-semibold backdrop-blur-xs">
              <Leaf className="w-3.5 h-3.5 text-[#a8cf92]" />
              <span>بفرمایید سر سفره اصیل ایرانی</span>
            </div>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black leading-snug">
              عطر خوش خاطره‌ها منتظر آشپزخانه شماست
            </h2>

            <p className="text-xs sm:text-sm text-[#d4decb] leading-relaxed">
              از سبزی‌های قورمه و کوکوی تازه سرخ‌شده با روغن کنجد تا ترشی‌های جاافتاده هفت‌ساله و رب‌های
              دودی هیزمی، اصیل‌ترین طعم‌های خانگی ایران را با چند کلیک ساده مهمان خانه خود کنید.
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => onNavigate({ type: 'products' })}
                className="px-6 py-3 bg-[#8b2332] hover:bg-[#a02c3c] text-white rounded-full font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>مشاهده و خرید محصولات خانگی</span>
                <ArrowLeft className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate({ type: 'contact' })}
                className="px-5 py-3 bg-white text-[#2c3d28] hover:bg-[#f2ede4] rounded-full font-semibold text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer"
              >
                <Phone className="w-4 h-4 text-[#8b2332]" />
                <span>تماس با ما و مشاوره خرید</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
