import React from 'react';
import {
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowLeft,
  Truck,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { SITE_CONFIG } from '../data/config';
import { PageView } from '../types';

interface CartPageProps {
  onNavigate: (page: PageView) => void;
}

export const CartPage: React.FC<CartPageProps> = ({ onNavigate }) => {
  const { items, removeFromCart, updateQuantity, clearCart, totalPrice, totalCount } = useCart();

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16 text-center space-y-5">
        <div className="w-20 h-20 rounded-full bg-[#f4efe4] flex items-center justify-center mx-auto text-[#717c6e]">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h1 className="text-2xl font-black text-[#232724]">سبد خرید شما در حال حاضر خالی است</h1>
        <p className="text-xs sm:text-sm text-[#667262] max-w-md mx-auto leading-relaxed">
          عطر ترشی‌های هفت‌بیجار، رب انار هیزمی و سبزیجات آماده‌سازی‌شده کارگاه خوشمزه‌ها منتظر
          آشپزخانه شما هستند.
        </p>
        <button
          onClick={() => onNavigate({ type: 'products' })}
          className="mt-4 px-6 py-3 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-full font-bold text-xs sm:text-sm shadow-md transition-all inline-flex items-center gap-2 cursor-pointer"
        >
          <span>مشاهده و انتخاب محصولات خانگی</span>
          <ArrowLeft className="w-4 h-4" />
        </button>
      </div>
    );
  }

  const shippingCost = totalPrice >= SITE_CONFIG.freeShippingThreshold ? 0 : 45000;
  const finalTotal = totalPrice + shippingCost;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-10">
      {/* Breadcrumb & Header */}
      <div className="space-y-2 border-b border-[#ece5d8] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">سبد خرید ({totalCount} قلم)</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-black text-[#232724]">
          مدیریت و بازبینی سبد خرید
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Items List (Right in RTL) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between pb-2">
            <span className="text-xs font-bold text-[#717c6e]">محصولات انتخابی شما:</span>
            <button
              onClick={clearCart}
              className="text-xs text-[#8b2332] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>خالی کردن سبد</span>
            </button>
          </div>

          <div className="space-y-3">
            {items.map((item) => (
              <div
                key={`${item.product.id}-${item.selectedSize.label}`}
                className="bg-white p-4 sm:p-5 rounded-2xl border border-[#ebe4d6] shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4"
              >
                {/* Thumbnail & Titles */}
                <div className="flex items-center gap-4 w-full sm:w-auto">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl object-cover border border-[#eee8dc] shrink-0"
                  />
                  <div>
                    <h3
                      onClick={() =>
                        onNavigate({ type: 'product-detail', productId: item.product.id })
                      }
                      className="font-bold text-sm sm:text-base text-[#232724] hover:text-[#8b2332] transition-colors cursor-pointer"
                    >
                      {item.product.name}
                    </h3>
                    <span className="text-xs text-[#717c6e] block mt-0.5">
                      بسته‌بندی: {item.selectedSize.label}
                    </span>
                    <span className="text-xs text-[#8b2332] font-semibold block mt-1">
                      قیمت واحد: {item.selectedSize.price.toLocaleString('fa-IR')} تومان
                    </span>
                  </div>
                </div>

                {/* Stepper & Total */}
                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-[#f2ede4]">
                  {/* Stepper */}
                  <div className="flex items-center gap-2 bg-[#f6f2ea] rounded-xl p-1 border border-[#ded5c5]">
                    <button
                      onClick={() =>
                        updateQuantity(
                          item.product.id,
                          item.selectedSize.label,
                          item.quantity + 1
                        )
                      }
                      className="w-7 h-7 rounded-lg bg-white text-[#2c3d28] hover:bg-[#e6dfd1] flex items-center justify-center font-bold"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs font-bold w-6 text-center">
                      {item.quantity.toLocaleString('fa-IR')}
                    </span>
                    <button
                      onClick={() =>
                        updateQuantity(
                          item.product.id,
                          item.selectedSize.label,
                          item.quantity - 1
                        )
                      }
                      className="w-7 h-7 rounded-lg bg-white text-[#2c3d28] hover:bg-[#e6dfd1] flex items-center justify-center font-bold"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Line Total */}
                  <div className="text-left min-w-[90px]">
                    <span className="text-[10px] text-[#717c6e] block">مجموع:</span>
                    <div className="flex items-center gap-1 justify-end">
                      <span className="font-black text-sm sm:text-base text-[#232724]">
                        {(item.selectedSize.price * item.quantity).toLocaleString('fa-IR')}
                      </span>
                      <span className="text-[10px] text-[#717c6e]">تومان</span>
                    </div>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() =>
                      removeFromCart(item.product.id, item.selectedSize.label)
                    }
                    className="text-[#9ea79b] hover:text-[#8b2332] p-1.5 rounded-lg hover:bg-[#faecee] transition-colors"
                    title="حذف از سبد"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary Sidebar (Left in RTL) */}
        <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-5 sticky top-24">
          <h2 className="font-bold text-base text-[#232724] border-b border-[#eee8dc] pb-3">
            خلاصه صورت‌حساب
          </h2>

          <div className="space-y-3 text-xs text-[#556052]">
            <div className="flex items-center justify-between">
              <span>مجموع بهای اقلام:</span>
              <div className="flex items-center gap-1 font-bold text-[#232724]">
                <span>{totalPrice.toLocaleString('fa-IR')}</span>
                <span>تومان</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span>هزینه بسته‌بندی ایمن و ارسال:</span>
              <div className="flex items-center gap-1">
                {shippingCost === 0 ? (
                  <span className="text-[#3b5334] font-bold">رایگان (تخفیف کارگاه)</span>
                ) : (
                  <span className="font-bold text-[#232724]">
                    {shippingCost.toLocaleString('fa-IR')} تومان
                  </span>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-[#f2ede4] flex items-center justify-between text-sm">
              <span className="font-bold text-[#232724]">مبلغ نهایی قابل پرداخت:</span>
              <div className="flex items-center gap-1 text-[#8b2332] font-black text-lg">
                <span>{finalTotal.toLocaleString('fa-IR')}</span>
                <span className="text-xs font-normal text-[#6e7769]">تومان</span>
              </div>
            </div>
          </div>

          {/* Payment Notice */}
          <div className="bg-[#fcfbf7] p-3 rounded-xl border border-[#ebe4d6] text-[11px] text-[#717c6e] leading-relaxed">
            💡 در مرحله بعد، اطلاعات نشانی خود را وارد می‌کنید و پس از کلیک بر روی «ثبت نهایی سفارش»،
            فاکتور به بات پیام‌رسان تلگرام کارگاه جهت هماهنگی و ارسال هدایت می‌شود.
          </div>

          <button
            onClick={() => onNavigate({ type: 'checkout' })}
            className="w-full py-3.5 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>ادامه و ثبت نهایی سفارش</span>
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
