import React, { useState, useMemo } from 'react';
import { Search, Filter, SlidersHorizontal, Sparkles, X, ChevronDown } from 'lucide-react';
import { ProductCard } from '../components/common/ProductCard';
import { PRODUCTS, CATEGORIES } from '../data/products';
import { PageView } from '../types';

interface ProductsPageProps {
  initialCategorySlug?: string;
  initialSeasonalOnly?: boolean;
  onNavigate: (page: PageView) => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({
  initialCategorySlug,
  initialSeasonalOnly = false,
  onNavigate,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategorySlug || 'all');
  const [searchQuery, setSearchQuery] = useState('');
  const [seasonalOnly, setSeasonalOnly] = useState(initialSeasonalOnly);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'popular' | 'price-asc' | 'price-desc' | 'rating'>('popular');

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      // Category filter
      if (selectedCategory !== 'all' && product.categorySlug !== selectedCategory) {
        return false;
      }
      // Seasonal filter
      if (seasonalOnly && !product.isSeasonal) {
        return false;
      }
      // Stock filter
      if (inStockOnly && !product.inStock) {
        return false;
      }
      // Search query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = product.name.toLowerCase().includes(q);
        const matchesDesc = product.shortDescription.toLowerCase().includes(q);
        const matchesCat = product.category.toLowerCase().includes(q);
        const matchesOrigin = product.origin.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesCat && !matchesOrigin) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.basePrice - b.basePrice;
      if (sortBy === 'price-desc') return b.basePrice - a.basePrice;
      if (sortBy === 'rating') return b.rating - a.rating;
      return b.reviewsCount - a.reviewsCount; // popular
    });
  }, [selectedCategory, seasonalOnly, inStockOnly, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-8">
      {/* Page Title & Breadcrumbs */}
      <div className="space-y-2 border-b border-[#ece5d8] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">کاتالوگ محصولات</span>
          {selectedCategory !== 'all' && (
            <>
              <span>/</span>
              <span className="text-[#8b2332]">
                {CATEGORIES.find((c) => c.slug === selectedCategory)?.name}
              </span>
            </>
          )}
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
          کاتالوگ کامل خوراکی‌های خانگی و سنتی «خوشمزه‌ها»
        </h1>
        <p className="text-xs sm:text-sm text-[#667262] max-w-3xl leading-relaxed">
          تمامی محصولات به صورت دست‌ساز، آرام‌پز در دیگ‌های مس و با بهترین مواد اولیه تازه بدون هیچ‌گونه
          رنگ، نشاسته یا نگهدارنده صنعتی در مطبخ کارگاه آماده می‌شوند.
        </p>
      </div>

      {/* Category Filter Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`shrink-0 px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
            selectedCategory === 'all'
              ? 'bg-[#2c3d28] text-white shadow-xs'
              : 'bg-white text-[#454f42] border border-[#e2dacf] hover:bg-[#f5f1e8]'
          }`}
        >
          همه محصولات ({PRODUCTS.length})
        </button>

        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.slug)}
            className={`shrink-0 px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
              selectedCategory === cat.slug
                ? 'bg-[#2c3d28] text-white shadow-xs'
                : 'bg-white text-[#454f42] border border-[#e2dacf] hover:bg-[#f5f1e8]'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Search, Filter & Sort Controls */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="جستجو در نام محصول، چاشنی، مواد اولیه..."
            className="w-full pl-9 pr-10 py-2.5 bg-[#fbf9f4] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white transition-colors"
          />
          <Search className="w-4 h-4 text-[#8a9586] absolute right-3.5 top-1/2 -translate-y-1/2" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8a9586] hover:text-[#232724]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Toggles & Sort Options */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Seasonal Toggle */}
          <button
            onClick={() => setSeasonalOnly(!seasonalOnly)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium border transition-colors flex items-center gap-1.5 cursor-pointer ${
              seasonalOnly
                ? 'bg-[#8b2332] text-white border-[#8b2332]'
                : 'bg-[#faf7f0] text-[#556052] border-[#ded5c5] hover:border-[#8b2332]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>نوبارانه‌های این فصل</span>
          </button>

          {/* In Stock Toggle */}
          <button
            onClick={() => setInStockOnly(!inStockOnly)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium border transition-colors cursor-pointer ${
              inStockOnly
                ? 'bg-[#2c3d28] text-white border-[#2c3d28]'
                : 'bg-[#faf7f0] text-[#556052] border-[#ded5c5] hover:border-[#2c3d28]'
            }`}
          >
            <span>فقط موجود در کارگاه</span>
          </button>

          {/* Sort By Dropdown */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="appearance-none pr-8 pl-8 py-2 bg-[#faf7f0] border border-[#ded5c5] rounded-xl text-xs font-medium text-[#2c3d28] focus:outline-none focus:border-[#2c3d28] cursor-pointer"
            >
              <option value="popular">مرتب‌سازی: محبوب‌ترین</option>
              <option value="rating">بیشترین امتیاز مشتریان</option>
              <option value="price-asc">ارزان‌ترین به گران‌ترین</option>
              <option value="price-desc">گران‌ترین به ارزان‌ترین</option>
            </select>
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#889283] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Active Filters Display */}
      {(selectedCategory !== 'all' || seasonalOnly || inStockOnly || searchQuery) && (
        <div className="flex items-center gap-2 flex-wrap text-xs text-[#717c6e]">
          <span>فیلترهای فعال:</span>
          {selectedCategory !== 'all' && (
            <span className="bg-[#ede7da] text-[#2c3d28] px-2.5 py-1 rounded-full flex items-center gap-1">
              دسته‌بندی: {CATEGORIES.find((c) => c.slug === selectedCategory)?.name}
              <X
                className="w-3 h-3 cursor-pointer hover:text-black"
                onClick={() => setSelectedCategory('all')}
              />
            </span>
          )}
          {seasonalOnly && (
            <span className="bg-[#faecee] text-[#8b2332] px-2.5 py-1 rounded-full flex items-center gap-1">
              محصولات فصلی
              <X
                className="w-3 h-3 cursor-pointer hover:text-black"
                onClick={() => setSeasonalOnly(false)}
              />
            </span>
          )}
          {inStockOnly && (
            <span className="bg-[#eef3ea] text-[#2c3d28] px-2.5 py-1 rounded-full flex items-center gap-1">
              تنها موجودها
              <X
                className="w-3 h-3 cursor-pointer hover:text-black"
                onClick={() => setInStockOnly(false)}
              />
            </span>
          )}
          {searchQuery && (
            <span className="bg-[#ede7da] text-[#2c3d28] px-2.5 py-1 rounded-full flex items-center gap-1">
              جستجو: {searchQuery}
              <X
                className="w-3 h-3 cursor-pointer hover:text-black"
                onClick={() => setSearchQuery('')}
              />
            </span>
          )}
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSeasonalOnly(false);
              setInStockOnly(false);
              setSearchQuery('');
            }}
            className="text-[#8b2332] underline hover:text-[#6e1925] mr-2"
          >
            پاک کردن همه
          </button>
        </div>
      )}

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-[#e8e2d4] space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#f6f2ea] flex items-center justify-center mx-auto text-[#889283]">
            <Search className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-lg text-[#232724]">محصولی با این مشخصات یافت نشد</h3>
          <p className="text-xs text-[#717c6e] max-w-md mx-auto">
            لطفاً عبارت دیگری را جستجو کنید یا فیلترهای اعمال‌شده را تغییر دهید.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSeasonalOnly(false);
              setInStockOnly(false);
              setSearchQuery('');
            }}
            className="px-5 py-2.5 bg-[#2c3d28] text-white text-xs font-semibold rounded-full hover:bg-[#384e33]"
          >
            مشاهده تمام محصولات
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onNavigate={(id) => onNavigate({ type: 'product-detail', productId: id })}
            />
          ))}
        </div>
      )}
    </div>
  );
};
