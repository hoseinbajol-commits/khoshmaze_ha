import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Send,
  CheckCircle2,
  ChefHat,
  MessageCircle,
} from 'lucide-react';
import { SITE_CONFIG, TELEGRAM_BOT_URL } from '../data/config';
import { PageView } from '../types';

interface ContactPageProps {
  onNavigate: (page: PageView) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate }) => {
  const [formState, setFormState] = useState({
    name: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.phone || !formState.message) return;
    setSubmitted(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-12">
      {/* Breadcrumb & Header */}
      <div className="space-y-3 border-b border-[#ece5d8] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">تماس با ما و کارگاه</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-[#232724]">
          پل‌های ارتباطی کارگاه و مطبخ سنتی خوشمزه‌ها
        </h1>

        <p className="text-xs sm:text-sm text-[#5f6b5b] max-w-3xl leading-relaxed">
          برای مشاوره در انتخاب رب‌ها و چاشنی‌ها، پیگیری بسته‌های ارسالی یا ثبت سفارشات نذری و عمده
          سبزیجات تازه، با مهر پاسخگوی شما عزیزان هستیم.
        </p>
      </div>

      {/* Main Grid: Contact Info & Contact Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Info Cards (Right) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Central Workshop Address */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-[#8b2332]">
              <MapPin className="w-5 h-5" />
              <h3 className="font-extrabold text-sm text-[#232724]">نشانی مطبخ مرکزی (لرستان)</h3>
            </div>
            <p className="text-xs text-[#556052] leading-relaxed">
              {SITE_CONFIG.address}
            </p>
            <span className="text-[11px] text-[#717c6e] block pt-1">
              (بازدید با هماهنگی قبلی همه روزه در ساعات پخت امکان‌پذیر است)
            </span>
          </div>

          {/* Tajrish Showroom */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-[#2c3d28]">
              <ChefHat className="w-5 h-5" />
              <h3 className="font-extrabold text-sm text-[#232724]">شوروم معرفی و تحویل (تهران)</h3>
            </div>
            <p className="text-xs text-[#556052] leading-relaxed">
              {SITE_CONFIG.tajrishAddress}
            </p>
          </div>

          {/* Phone Numbers & Working Hours */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-4">
            <div className="space-y-3 text-xs text-[#556052]">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#3b5334] shrink-0" />
                <div>
                  <span className="text-[#717c6e] block text-[11px]">شماره تماس مستقیم کارگاه:</span>
                  <a
                    href={`tel:${SITE_CONFIG.phone}`}
                    className="font-bold text-sm text-[#2c3d28] hover:text-[#8b2332]"
                  >
                    {SITE_CONFIG.phoneDisplay}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#3b5334] shrink-0" />
                <div>
                  <span className="text-[#717c6e] block text-[11px]">تلفن دفتر مرکزی پشتیبانی:</span>
                  <a
                    href={`tel:${SITE_CONFIG.landline}`}
                    className="font-bold text-sm text-[#2c3d28] hover:text-[#8b2332]"
                  >
                    {SITE_CONFIG.landlineDisplay}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#3b5334] shrink-0" />
                <div>
                  <span className="text-[#717c6e] block text-[11px]">پست الکترونیکی:</span>
                  <a href={`mailto:${SITE_CONFIG.email}`} className="font-semibold text-[#2c3d28]">
                    {SITE_CONFIG.email}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-[#3b5334] shrink-0" />
                <div>
                  <span className="text-[#717c6e] block text-[11px]">ساعات کاری و پاسخ‌گویی:</span>
                  <span className="font-semibold text-[#232724]">{SITE_CONFIG.workingHours}</span>
                </div>
              </div>
            </div>

            {/* Direct Telegram Support Box */}
            <div className="pt-3 border-t border-[#f2ede4]">
              <a
                href={TELEGRAM_BOT_URL}
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 bg-[#f5f1e8] hover:bg-[#2c3d28] hover:text-white text-[#2c3d28] rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all border border-[#ded5c5]"
              >
                <MessageCircle className="w-4 h-4 text-[#8b2332]" />
                <span>ارتباط مستقیم از طریق بات تلگرام کارگاه</span>
              </a>
            </div>
          </div>
        </div>

        {/* Form (Left) */}
        <div className="lg:col-span-7 bg-white p-6 sm:p-10 rounded-3xl border border-[#ebe4d6] shadow-xs">
          {submitted ? (
            <div className="p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#f0f6ec] text-[#3b5334] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="font-black text-xl text-[#232724]">پیام شما با موفقیت ثبت شد</h3>
              <p className="text-xs sm:text-sm text-[#556052] max-w-md mx-auto leading-relaxed">
                سپاس از لطف شما. همکاران ما در مطبخ کارگاه در اسرع وقت پیام شما را مطالعه کرده و با شما
                تماس خواهند گرفت.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setFormState({ name: '', phone: '', subject: '', message: '' });
                }}
                className="px-5 py-2.5 bg-[#2c3d28] text-white text-xs font-semibold rounded-full hover:bg-[#384e33]"
              >
                ارسال پیام دیگر
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h3 className="font-black text-lg text-[#232724] mb-1">
                ارسال پیام یا پرسش درباره محصولات
              </h3>
              <p className="text-xs text-[#717c6e] mb-4">
                فرم زیر را تکمیل کنید تا کارشناسان مطبخ در سریع‌ترین زمان پاسخگوی شما باشند.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#353f32]">نام و نام خانوادگی:</label>
                  <input
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    placeholder="مثال: مریم کریمی"
                    className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white transition-colors"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#353f32]">شماره تماس همراه:</label>
                  <input
                    type="tel"
                    required
                    value={formState.phone}
                    onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                    placeholder="مثال: ۰۹۱۲۳۴۵۶۷۸۹"
                    className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-[#353f32]">موضوع پیام:</label>
                <input
                  type="text"
                  value={formState.subject}
                  onChange={(e) => setFormState({ ...formState, subject: e.target.value })}
                  placeholder="مثال: سوال درباره زمان ماندگاری ترشی یا سفارش سبزی نذری"
                  className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-[#353f32]">متن پیام یا سفارش:</label>
                <textarea
                  required
                  rows={5}
                  value={formState.message}
                  onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                  placeholder="پیام یا درخواست خود را اینجا بنویسید..."
                  className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white transition-colors resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>ارسال پیام به مطبخ کارگاه</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
