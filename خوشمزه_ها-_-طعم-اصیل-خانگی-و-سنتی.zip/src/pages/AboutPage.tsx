import React from 'react';
import {
  MapPin,
  Clock,
  Truck,
  Phone,
  ShieldCheck,
  Heart,
  Package,
  ChefHat,
  Leaf,
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  Quote,
} from 'lucide-react';
import { SITE_CONFIG } from '../data/config';
import { PageView } from '../types';

interface AboutPageProps {
  onNavigate: (page: PageView) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-16 sm:space-y-24 text-right py-6 sm:py-10">
      {/* 1. Breadcrumb & Hero Section (Matching Image 8 top) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="text-[#889283]">درباره کارگاه خانگی خوشمزه‌ها</span>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">اصالت، ریشه و باورهای ما</span>
        </div>

        {/* Hero Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Right Column: Hero text & Stats */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 bg-[#eae3d5] text-[#2c3d28] text-xs font-semibold px-3.5 py-1.5 rounded-full border border-[#ded5c5]">
              <span className="w-2 h-2 rounded-full bg-[#8b2332] animate-pulse" />
              <span>روایت یک عشق؛ از مطبخ تجریش تا سفره‌های یک ایرانی</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#232724] leading-tight">
              داستان خوشمزه‌ها؛
              <span className="text-[#8b2332] block mt-2">
                طعم اصیل خاطرات مادر و عطر سبزی تازه
              </span>
            </h1>

            <div className="space-y-4 text-xs sm:text-sm text-[#556052] leading-relaxed">
              <p>
                شروع ماجرا از اواخر دهه نود خورشیدی و آشپزخانه‌ای نقلی با پنجره‌های چوبی رو به باغ‌های
                قدیمی تجریش کلید خورد. روزگاری که شتاب کارخانه‌ای و طعم‌های کنسروی بی‌روح، رفته‌رفته
                بوی نغز داغ‌اصیل، رب‌های گوجه فرنگی را از یادها می‌برد و ترشی‌های هفت‌بیجار خانگی را از
                خاطره شهر می‌زدود.
              </p>
              <p>
                ما در «خوشمزه‌ها» دست به کار شدیم تا زنجیره فراموش‌شده احترام به ماده اولیه، پاکیزگی
                بی‌تعارف و دلسوزی مادرانه را زنده نگه داریم. در این سبزی، هر دانه غوره و هر بوته اناری که
                به مطبخ ما می‌رسد، نه یک کالای انبوه تجاری، بلکه امانت دستان زحمت‌کش باغبانانی است که
                بدون کود شیمیایی و با مهر زمین پرورده شده است.
              </p>
            </div>

            {/* 3 Stats Boxes (Image 8) */}
            <div className="grid grid-cols-3 gap-3 pt-2">
              <div className="bg-[#fbf9f4] p-4 rounded-2xl border border-[#ebe4d6] text-center">
                <span className="block font-black text-2xl sm:text-3xl text-[#2c3d28]">۸ سال</span>
                <span className="text-[11px] text-[#717c6e] font-medium mt-1 block">
                  پخت و پاکسازی اصیل
                </span>
              </div>

              <div className="bg-[#fbf9f4] p-4 rounded-2xl border border-[#ebe4d6] text-center">
                <span className="block font-black text-2xl sm:text-3xl text-[#8b2332]">+۲۶</span>
                <span className="text-[11px] text-[#717c6e] font-medium mt-1 block">
                  بانوی هنرمند محلی
                </span>
              </div>

              <div className="bg-[#fbf9f4] p-4 rounded-2xl border border-[#ebe4d6] text-center">
                <span className="block font-black text-2xl sm:text-3xl text-[#2c3d28]">۱۰۰</span>
                <span className="text-[11px] text-[#717c6e] font-medium mt-1 block">
                  محصول پخت خانگی
                </span>
              </div>
            </div>
          </div>

          {/* Left Column: Workshop Photo with Badges */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden border-4 border-white shadow-xl bg-[#eadecc]">
              <img
                src="/src/assets/images/workshop_mothers.jpg"
                alt="مطبخ مرکزی مادرانه"
                className="w-full h-[400px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />

              {/* Bottom Badge: Workshop in Doroud */}
              <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-md p-3 rounded-2xl border border-[#ebe4d6] shadow-sm flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#2c3d28] text-white flex items-center justify-center">
                  <ChefHat className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <span className="font-extrabold text-xs text-[#232724] block">
                    مطبخ مرکزی مادرانه
                  </span>
                  <span className="text-[10px] text-[#697464]">لرستان، دورود</span>
                </div>
              </div>

              {/* Badge: Pure Aroma */}
              <div className="absolute top-4 left-4 bg-[#8b2332] text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-sm">
                عطر اصیل
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Section: مرامنامه و شیوه‌نامه کارگاه (Image 8) */}
      <section className="bg-[#faf7f0] py-14 border-y border-[#ece5d8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#8b2332] block">مرامنامه و شیوه‌نامه کارگاه</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
              فلسفه آرام‌پزی و احترام به چرخه طبیعی فصول
            </h2>
            <p className="text-xs sm:text-sm text-[#667262] leading-relaxed">
              ما بر این باوریم که خوراک خوب زمان می‌خواهد. سبزی نوبارانه باید در ماه خودش چیده شود و
              جوشیدن رب باید زیر سایه‌سار پاییز با شعله ملایم صورت گیرد.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Card 1: احترام به طبیعت و دست‌چین فصلی */}
            <div className="bg-white p-7 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-4 text-right flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-11 h-11 rounded-2xl bg-[#eef4ea] text-[#3b5334] flex items-center justify-center">
                  <Leaf className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-[#232724]">
                  احترام به طبیعت و دست‌چین فصلی
                </h3>
                <p className="text-xs sm:text-sm text-[#556052] leading-relaxed">
                  ما هیچ صیفی‌جات یا گیاهی را به شکل فله‌ای و منجمد چندساله انبار نمی‌کنیم. با شروع
                  اردیبهشت، باقالی تازه و شوید معطر را مستقیماً از شالیزارها و مزارع دورود لرستان می‌آوریم
                  و در پاییز، انار ساوه و گوجه فرنگی را به دیگ‌ها می‌سپاریم. تطابق با چرخه آب‌وهوا
                  نه‌تنها تعهد ما، بلکه امانت دستان «خوشمزه‌ها»ست.
                </p>
              </div>

              <div className="pt-4 border-t border-[#f2ede4] flex items-center gap-2 text-xs font-semibold text-[#3b5334]">
                <CheckCircle2 className="w-4 h-4" />
                <span>تأمین مستقیم از باغداران بومی و بدون واسطه دلالان</span>
              </div>
            </div>

            {/* Card 2: آرام‌پزی، ظروف و فرآوری صبورانه */}
            <div className="bg-white p-7 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-4 text-right flex flex-col justify-between">
              <div className="space-y-3">
                <div className="w-11 h-11 rounded-2xl bg-[#faecee] text-[#8b2332] flex items-center justify-center">
                  <ChefHat className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-[#232724]">
                  آرام‌پزی، ظروف و فرآوری صبورانه
                </h3>
                <p className="text-xs sm:text-sm text-[#556052] leading-relaxed">
                  ترشی‌های ما با سرکه دست‌ساز انگور عسکری و سیب به بار می‌نشینند؛ هیچ شتاب‌دهنده
                  شیمیایی و اسید سیتریکی در مطبخ راه ندارد. رب گوجه و لواشک‌های ترش و ملس ساعت‌ها در
                  دیگ‌های سنگین قل می‌زنند تا شهد طبیعی و غلظت خالص خورشیدی پدیدار گردد.
                </p>
              </div>

              <div className="pt-4 border-t border-[#f2ede4] flex items-center gap-2 text-xs font-semibold text-[#8b2332]">
                <CheckCircle2 className="w-4 h-4" />
                <span>شیشه‌بندی استریل و پلمپ سنتی با موم و نخ کنفی</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Section: مستندات کارگاه و دست‌چین‌های واقعی (Image 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-1">
          <span className="text-xs font-bold text-[#8b2332] block">مستندات کارگاه و دست‌چین‌های واقعی</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
            نمایی بی‌پیراست از مواد اولیه، آماده‌سازی دستی و شیشه‌های دست‌رنج بانوان
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: باقالی سبز دست‌پوست */}
          <div className="bg-white rounded-3xl border border-[#ebe4d6] overflow-hidden shadow-xs text-right flex flex-col justify-between">
            <div className="relative aspect-4/3 overflow-hidden bg-[#f4efe6]">
              <img
                src="/src/assets/images/broad_beans.jpg"
                alt="باقالی سبز دست‌پوست"
                className="w-full h-full object-cover"
              />
              <span className="absolute top-3 right-3 bg-white/95 text-[#2c3d28] text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
                سبزیجات و نوبارانه
              </span>
            </div>
            <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-base text-[#232724]">باقالی سبز دست‌پوست</h3>
                <p className="text-xs text-[#556052] mt-1 leading-relaxed">
                  دانه‌شده و پوست‌دوم‌گرفته با دقت تمام توسط مادران کارگاه، آماده باقالی‌پلو با عطر و
                  تردی باغ‌های بهاری.
                </p>
              </div>
              <div className="pt-3 border-t border-[#f2ede4] flex items-center gap-1.5 text-xs text-[#3b5334] font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>شستشوی سه‌مرحله‌ای با آب روان</span>
              </div>
            </div>
          </div>

          {/* Card 2: ترخینه دوغی و پونه وحشی */}
          <div className="bg-white rounded-3xl border border-[#ebe4d6] overflow-hidden shadow-xs text-right flex flex-col justify-between">
            <div className="relative aspect-4/3 overflow-hidden bg-[#f4efe6]">
              <img
                src="/src/assets/images/tarkhineh_balls.jpg"
                alt="ترخینه دوغی و پونه وحشی"
                className="w-full h-full object-cover"
              />
              <span className="absolute top-3 right-3 bg-white/95 text-[#8b2332] text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
                میراث کوهستان
              </span>
            </div>
            <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-base text-[#232724]">ترخینه دوغی و پونه وحشی</h3>
                <p className="text-xs text-[#556052] mt-1 leading-relaxed">
                  خمیر سنتی بلغور گندم پخته‌شده در دوغ ترش محلی به همراه پونه کوهی لرستان، خشک‌شده در
                  آفتاب زلال دامنه.
                </p>
              </div>
              <div className="pt-3 border-t border-[#f2ede4] flex items-center gap-1.5 text-xs text-[#8b2332] font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>خشک‌شده به روش طبیعی آفتاب‌پز</span>
              </div>
            </div>
          </div>

          {/* Card 3: شیشه‌های کرافت و چاشنی اصیل */}
          <div className="bg-white rounded-3xl border border-[#ebe4d6] overflow-hidden shadow-xs text-right flex flex-col justify-between">
            <div className="relative aspect-4/3 overflow-hidden bg-[#f4efe6]">
              <img
                src="/src/assets/images/craft_jars.jpg"
                alt="شیشه‌های کرافت و چاشنی اصیل"
                className="w-full h-full object-cover"
              />
              <span className="absolute top-3 right-3 bg-white/95 text-[#2c3d28] text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-xs">
                بسته‌بندی پاک
              </span>
            </div>
            <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-base text-[#232724]">شیشه‌های کرافت و چاشنی اصیل</h3>
                <p className="text-xs text-[#556052] mt-1 leading-relaxed">
                  رب انار غلیظ ملس، ترشی هفت‌بیجار، شربت‌های سکنجبین و آب‌غوره طبیعی در ظروف شیشه‌ای
                  کاملاً بهداشتی و برچسب شناسنامه‌دار.
                </p>
              </div>
              <div className="pt-3 border-t border-[#f2ede4] flex items-center gap-1.5 text-xs text-[#3b5334] font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>پلمپ و بسته‌بندی عاری از پلاستیک مضر</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Section: سوگندنامه طعم و سلامت (چهار اصل استوار از Image 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold text-[#8b2332] block mb-1">سوگندنامه طعم و سلامت</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
            چهار اصل استوار که هرگز از آن کوتاه نمی‌آییم
          </h2>
          <p className="text-xs sm:text-sm text-[#677263] mt-2">
            بدون ادعاهای بزرگ‌نمایی‌شده صنعتی؛ آنچه در شیشه‌های ماست حاصل راستی دستان و وجدان کاری ماست.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#f0ebd0] text-[#2c3d28] flex items-center justify-center mb-4">
                <ShieldCheck className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                ۱۰۰٪ سلامت‌محور و بدون نگه‌دارنده
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                هیچ نوع رنگ، بنزوات سدیم، اسانس شباهت طعم یا ماده قوام‌دهنده در مطبخ وجود ندارد.
                ماندگاری تنها با سرکه و جوشاندن اصولی پدید می‌آید.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#4e6b39] pt-4 mt-2 border-t border-[#f3eee4]">
              ضمانت خلوص غذا
            </span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#faecee] text-[#8b2332] flex items-center justify-center mb-4">
                <Heart className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                دست‌رنج بانوان و احیای مهارت‌ها
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                کارگاه خوشمزه‌ها بستر اشتغال پایدار و شرافتمندانه برای مادران سرپرست خانوار و بانوان صاحب
                تجربه است تا هنر دست‌شان ارزش واقعی بیابد.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#8b2332] pt-4 mt-2 border-t border-[#f3eee4]">
              اشتغال محلی و توانمندسازی
            </span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#eef3ea] text-[#3d5930] flex items-center justify-center mb-4">
                <Package className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                شفافیت و شناسنامه برای هر شیشه
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                روی برچسب هر شیشه، نام مبدأ میوه یا سبزی (مثلاً انار ساوه، سیر طارم) و تاریخ دقیق پخت به
                صورت خوانا و شفاف ثبت شده است.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#3d5930] pt-4 mt-2 border-t border-[#f3eee4]">
              شناسنامه و طبع خوراک
            </span>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-[#ebe5d8] shadow-xs flex flex-col justify-between text-right">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#f2efe8] text-[#5c6856] flex items-center justify-center mb-4">
                <ChefHat className="w-5 h-5 stroke-[2]" />
              </div>
              <h3 className="font-bold text-sm text-[#232724] mb-2">
                بهداشت مدرن با طعم دست‌پخت مادر
              </h3>
              <p className="text-xs text-[#636e5f] leading-relaxed">
                پایبندی به مقررات بهداشتی و آزمایشگاه مواد غذایی در عین حفظ سنت‌ها؛ استریل شیشه‌ها و لباس
                کار استاندارد دوشادوش مهربانی مطبخ.
              </p>
            </div>
            <span className="text-[11px] font-semibold text-[#5c6856] pt-4 mt-2 border-t border-[#f3eee4]">
              استاندارد و نظارت سختگیرانه
            </span>
          </div>
        </div>
      </section>

      {/* 5. Section: کارگاه و مطبخ مرکزی در شهرستان دورود، لرستان (Image 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="bg-[#fcfbf7] rounded-3xl border border-[#ebe4d6] p-6 sm:p-10 shadow-xs space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#eee7da] pb-6">
            <div>
              <span className="text-xs font-bold text-[#3b5334] bg-[#eef4ea] px-3 py-1 rounded-full inline-block mb-2">
                درهای کارگاه ما همواره به روی شما گشوده است
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
                کارگاه و مطبخ مرکزی خوشمزه‌ها در شهرستان دورود، لرستان
              </h2>
              <p className="text-xs sm:text-sm text-[#667262] mt-1 max-w-2xl">
                اگر در ساعات صبح به کوچه نثار در نزدیکی میدان تجریش سر بزنید، عطر بوی سرخ کردن سبزی
                قورمه با روغن کنجد یا جوشیدن شربت آلبالوی تازه تمام محله را پر کرده است. شما می‌توانید
                فرآیند آماده‌سازی، پاک کردن دانه‌ای سبزی‌ها و بسته‌بندی در شیشه‌های شفاف را از پشت
                پنجره‌های کارگاه با چشم خود به تماشا بنشینید.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Map representation (Left in layout) */}
            <div className="lg:col-span-6 bg-[#f4f0e6] rounded-2xl border border-[#e4ded2] p-6 flex flex-col items-center justify-center text-center relative overflow-hidden min-h-[260px]">
              {/* Map stylized graphics */}
              <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#2c3d28_1px,transparent_1px)] [background-size:16px_16px]" />
              <div className="relative z-10 space-y-3">
                <div className="w-12 h-12 rounded-full bg-[#8b2332] text-white flex items-center justify-center mx-auto shadow-md animate-bounce">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-[#232724]">
                    موقعیت کارگاه مرکزی در دورود، لرستان
                  </h4>
                  <span className="text-xs text-[#717c6e]">پشت طبیعت بران، دشت لاله‌های واژگون</span>
                </div>
                <div className="inline-block bg-white/90 text-[#2c3d28] text-xs font-semibold px-4 py-1.5 rounded-full border border-[#ded5c5]">
                  کوی حکمت، مطبخ مادرانه خوشمزه‌ها
                </div>
              </div>
            </div>

            {/* 4 Info Boxes (Right in layout) */}
            <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="bg-white p-4 rounded-xl border border-[#ebe4d6] flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#8b2332] shrink-0 mt-0.5" />
                <div className="text-right">
                  <span className="font-bold text-xs text-[#232724] block">نشانی مطبخ</span>
                  <span className="text-xs text-[#6e7769]">{SITE_CONFIG.address}</span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#ebe4d6] flex items-start gap-3">
                <Clock className="w-5 h-5 text-[#3b5334] shrink-0 mt-0.5" />
                <div className="text-right">
                  <span className="font-bold text-xs text-[#232724] block">ساعات فعالیت و پخت</span>
                  <span className="text-xs text-[#6e7769]">{SITE_CONFIG.workingHours}</span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#ebe4d6] flex items-start gap-3">
                <Truck className="w-5 h-5 text-[#3b5334] shrink-0 mt-0.5" />
                <div className="text-right">
                  <span className="font-bold text-xs text-[#232724] block">ارسال خنک و مطمئن</span>
                  <span className="text-xs text-[#6e7769]">
                    تحویل روزانه با کلمن و ارسال پیشتاز به سراسر کشور
                  </span>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-[#ebe4d6] flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#8b2332] shrink-0 mt-0.5" />
                <div className="text-right">
                  <span className="font-bold text-xs text-[#232724] block">پاسخ‌گویی مستمر</span>
                  <span className="text-xs text-[#6e7769]">
                    گفتگو با مشاور تغذیه و ثبت سفارش‌های خانوادگی
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Quote Banner (Image 8) */}
          <div className="bg-[#f5f1e6] p-5 sm:p-6 rounded-2xl border border-[#e4ded0] flex items-center gap-4 text-right">
            <Quote className="w-8 h-8 text-[#8b2332] shrink-0 rotate-180 opacity-70" />
            <div className="flex-1">
              <p className="font-bold text-xs sm:text-sm text-[#232724] leading-relaxed">
                «ما غذایی را به شیشه می‌کشیم که با آسودگی خاطر بر سر سفره فرزندان و عزیزان خودمان
                می‌گذاریم؛ این تمام راز عطر مطبخ خوشمزه‌هاست.»
              </p>
              <span className="text-[11px] text-[#717c6e] mt-1 block">
                دست‌نوشت مادر بزرگ‌های کوی حکمت
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Call to Action Banner (from Image 8) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="rounded-3xl bg-[#283824] text-white p-8 sm:p-12 relative overflow-hidden text-center shadow-lg border border-[#374932]">
          <div className="relative z-10 max-w-2xl mx-auto space-y-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-[#d0e2c8] text-xs font-semibold backdrop-blur-xs">
              <Leaf className="w-3.5 h-3.5 text-[#a8cf92]" />
              <span>بفرمایید سر سفره اصیل ایرانی</span>
            </div>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black leading-snug">
              عطر خوش خاطره‌ها منتظر آشپزخانه شماست
            </h2>

            <p className="text-xs sm:text-sm text-[#d4decb] leading-relaxed">
              از سبزی‌های قورمه و کوکوی تازه سرخ‌شده با روغن کنجد تا ترشی‌های جاافتاده هفت‌ساله و رب‌های
              دودی هیزمی، اصیل‌ترین طعم‌های خانگی ایران را با چند کلیک ساده مهمان خانه خود کنید.
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => onNavigate({ type: 'products' })}
                className="px-6 py-3 bg-[#8b2332] hover:bg-[#a02c3c] text-white rounded-full font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>مشاهده و خرید محصولات خانگی</span>
                <ArrowLeft className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate({ type: 'contact' })}
                className="px-5 py-3 bg-white text-[#2c3d28] hover:bg-[#f2ede4] rounded-full font-semibold text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer"
              >
                <Phone className="w-4 h-4 text-[#8b2332]" />
                <span>تماس با ما و مشاوره خرید</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
