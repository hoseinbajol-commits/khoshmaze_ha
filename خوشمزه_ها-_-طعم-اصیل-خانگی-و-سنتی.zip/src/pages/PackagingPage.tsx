import React from 'react';
import {
  PackageCheck,
  ShieldCheck,
  Truck,
  RotateCcw,
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  Box,
  ThermometerSnowflake,
} from 'lucide-react';
import { PageView } from '../types';

interface PackagingPageProps {
  onNavigate: (page: PageView) => void;
}

export const PackagingPage: React.FC<PackagingPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-12">
      {/* Breadcrumb & Header */}
      <div className="space-y-3 border-b border-[#ece5d8] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">شیوه‌نامه بسته‌بندی و ارسال</span>
        </div>

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#faecee] text-[#8b2332] text-xs font-bold border border-[#f3d4d8]">
          <PackageCheck className="w-3.5 h-3.5" />
          <span>پلمپ ایمن و بسته‌بندی ضدضربه</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-[#232724]">
          بسته‌بندی پاک و ارسال خنک و مطمئن به سراسر ایران
        </h1>

        <p className="text-xs sm:text-sm text-[#5f6b5b] max-w-3xl leading-relaxed">
          یکی از دغدغه‌های همیشگی در خرید آنلاین چاشنی‌های شیشه‌ای و سبزیجات تازه، سلامت فیزیکی شیشه‌ها
          و حفظ زنجیره سرمای سبزی‌هاست. ما با طراحی اختصاصی بسته‌بندی‌های چندلایه، سلامت ۱۰۰٪ سفره شما
          را تضمین کرده‌ایم.
        </p>
      </div>

      {/* 4 Pillars of Safe Packaging */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Pillar 1 */}
        <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-[#f0ebd0] text-[#2c3d28] flex items-center justify-center">
              <Box className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">شیشه‌های مقاوم و استریل</h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              مواد اسیدی نظیر سرکه، آبغوره و رب انار به هیچ‌عنوان نباید در ظروف پلاستیکی پت نگهداری
              شوند. تمام محصولات ما در شیشه‌های استاندارد بهداشتی عاری از هرگونه مواد شیمیایی عرضه
              می‌شوند.
            </p>
          </div>
          <span className="text-[11px] font-bold text-[#3b5334] pt-2 border-t border-[#f2ede4]">
            حفظ سلامت و اصالت طعم
          </span>
        </div>

        {/* Pillar 2 */}
        <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-[#faecee] text-[#8b2332] flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">پلمپ مومی و کنف سنتی</h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              درب تمام شیشه‌ها پس از خنک‌سازی با موم طبیعی زنبور عسل و نخ کنفی دست‌باف محکم پلمپ
              می‌شود تا از نفوذ هوا کاملاً جلوگیری کرده و اصالت و دست‌نخوردگی آن تضمین شود.
            </p>
          </div>
          <span className="text-[11px] font-bold text-[#8b2332] pt-2 border-t border-[#f2ede4]">
            شناسنامه و اصالت دست‌پخت
          </span>
        </div>

        {/* Pillar 3 */}
        <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-[#eef3ea] text-[#3d5930] flex items-center justify-center">
              <PackageCheck className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">محافظ ضربه‌گیر چندلایه</h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              هر شیشه با نایلون‌های حباب‌دار هوایی ضخیم، جداکننده‌های مقوای کرافت پنج‌لایه و فوم محافظ
              تک‌به‌تک پوشانده می‌شود تا در برابر سخت‌ترین تکان‌های باربری مصون بماند.
            </p>
          </div>
          <span className="text-[11px] font-bold text-[#3d5930] pt-2 border-t border-[#f2ede4]">
            تضمین سلامت بدون شکستگی
          </span>
        </div>

        {/* Pillar 4 */}
        <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-[#eaf1f7] text-[#285780] flex items-center justify-center">
              <ThermometerSnowflake className="w-6 h-6" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">ارسال خنک با یخ خشک</h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              سبزیجات سرخ‌شده قورمه و باقالی‌های پوست‌دوم‌گرفته درون کلمن‌های ایزوله حرارتی مجهز به
              ژل‌های یخ بهداشتی قرار می‌گیرند تا دمای زیر صفر در تمام مسیر حفظ گردد.
            </p>
          </div>
          <span className="text-[11px] font-bold text-[#285780] pt-2 border-t border-[#f2ede4]">
            حفظ زنجیره سرمای استاندارد
          </span>
        </div>
      </div>

      {/* Visual Unboxing & Packaging Shelf */}
      <div className="bg-[#fbf9f4] p-6 sm:p-10 rounded-3xl border border-[#ebe4d6] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-6 space-y-4">
          <span className="text-xs font-bold text-[#8b2332]">سوغات در شأن خانه و سفره ایرانی</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
            شیشه‌هایی که دیدنشان اشتها می‌آورد
          </h2>
          <p className="text-xs sm:text-sm text-[#556052] leading-relaxed">
            ما باور داریم زیبایی بصری و تمیزی پاکیزه، بخشی از احترام ما به سفره شماست. از لیبل‌های
            کرافت خوانا که تمام مشخصات پخت را درج کرده‌اند تا بسته‌بندی بدون پلاستیک‌های بازیافتی
            نامرغوب، همه چیز طراحی شده تا با خیال آسوده بسته‌بندی را باز کنید.
          </p>

          <ul className="space-y-2.5 pt-2 text-xs text-[#3b5334] font-semibold">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>ارسال سریع با پست پیشتاز و تیپاکس هوایی به اقصی‌نقاط کشور</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>تحویل در بسته‌بندی کادویی کرافت برای سوغات و هدیه</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>بیمه کامل محموله و بازپرداخت فوری در صورت آسیب احتمالی</span>
            </li>
          </ul>
        </div>

        <div className="lg:col-span-6">
          <div className="rounded-3xl overflow-hidden border-4 border-white shadow-lg bg-[#eee6d8]">
            <img
              src="/src/assets/images/craft_jars.jpg"
              alt="بسته‌بندی پاک شیشه‌های کرافت"
              className="w-full h-80 object-cover"
            />
          </div>
        </div>
      </div>

      {/* Breakage Compensation Guarantee */}
      <div className="bg-[#2c3d28] text-white p-8 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-md">
        <div className="flex items-center gap-4 text-right">
          <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
            <RotateCcw className="w-7 h-7 text-[#a8cf92]" />
          </div>
          <div>
            <h3 className="font-extrabold text-lg text-white">ضمانت بی‌قیدوشرط تحویل سالم</h3>
            <p className="text-xs text-[#d6e4d0] mt-1 max-w-xl leading-relaxed">
              اگر به هر دلیلی شیشه‌ای در حین حمل دچار شکستگی شود، فقط با ارسال عکس شیشه شکسته، همان روز
              شیشه جدید را به رایگان و با هزینه کارگاه مجدداً برایتان ارسال می‌کنیم.
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate({ type: 'products' })}
          className="px-6 py-3 bg-[#8b2332] hover:bg-[#9e2d3d] text-white rounded-full text-xs font-bold transition-all shrink-0 flex items-center gap-2 shadow-xs cursor-pointer"
        >
          <span>مشاهده محصولات و ثبت سفارش</span>
          <ArrowLeft className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
