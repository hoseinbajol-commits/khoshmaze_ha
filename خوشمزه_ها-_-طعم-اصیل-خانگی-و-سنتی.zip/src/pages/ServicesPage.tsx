import React from 'react';
import {
  ChefHat,
  Leaf,
  Flame,
  CheckCircle2,
  Droplets,
  Scissors,
  ArrowLeft,
  Sparkles,
  Phone,
} from 'lucide-react';
import { SITE_CONFIG } from '../data/config';
import { PageView } from '../types';

interface ServicesPageProps {
  onNavigate: (page: PageView) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-12">
      {/* Breadcrumb & Header */}
      <div className="space-y-3 border-b border-[#ece5d8] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">خدمات آماده‌سازی سبزی</span>
        </div>

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#eef3ea] text-[#3d5930] text-xs font-bold border border-[#d2e2ca]">
          <ChefHat className="w-3.5 h-3.5" />
          <span>هنر دستان بانوان در مطبخ مرکزی</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-[#232724]">
          آماده‌سازی اصولی سبزیجات تازه؛ از مزرعه تا دیگ خورش
        </h1>

        <p className="text-xs sm:text-sm text-[#5f6b5b] max-w-3xl leading-relaxed">
          آماده‌کردن سبزی قورمه یا باقالی‌پلو یکی از وقت‌گیرترین و حساس‌ترین مراحل آشپزی است. اگر سبزی
          با تیغه تیز خرد نشود آب می‌اندازد و اگر با روغن بی‌کیفیت یا حرارت تند سرخ شود، خاصیت و عطرش
          از دست می‌رود. کارگاه «خوشمزه‌ها» تمام این زنجیره پرزحمت را با بالاترین استانداردهای سنتی برای
          شما انجام می‌دهد.
        </p>
      </div>

      {/* 6 Step Interactive Process */}
      <div className="space-y-6">
        <h2 className="text-xl sm:text-2xl font-bold text-[#232724]">
          مراحل شش‌گانه آماده‌سازی در مطبخ خوشمزه‌ها
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Step 1 */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-full bg-[#2c3d28] text-white flex items-center justify-center font-bold text-xs">
                ۱
              </span>
              <Leaf className="w-5 h-5 text-[#3b5334]" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">
              پاک‌سازی دانه‌ای با دست
            </h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              بانوان کارگاه، تک‌تک برگ‌ها را وارسی می‌کنند. ساقه‌های ضخیم و چوبی، برگ‌های پلاسیده یا زرد
              و هرگونه علف هرز به طور وسواسی جدا می‌شوند تا فقط جوانه و برگ ناب سبزی باقی بماند.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-full bg-[#2c3d28] text-white flex items-center justify-center font-bold text-xs">
                ۲
              </span>
              <Droplets className="w-5 h-5 text-[#285780]" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">
              شستشوی ۳ مرحله‌ای با آب روان
            </h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              سبزیجات در حوضچه‌های ته‌نشینی ابتدا گل‌زدایی می‌شوند، سپس با نمک طبیعی و سرکه دست‌ساز
              ضدعفونی گردیده و در پایان با دوش‌های پرفشار آب سرد چشمه آبکشی می‌گردند.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-full bg-[#2c3d28] text-white flex items-center justify-center font-bold text-xs">
                ۳
              </span>
              <Sparkles className="w-5 h-5 text-[#8b2332]" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">
              آب‌گیری و خشک‌کردن با پارچه چلوار
            </h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              سبزیجات خیس هرگز نباید خرد شوند چون له می‌شوند. سبزی‌ها روی پارچه‌های نخی چلوار در جریان
              هوای خنک و بهداشتی پهن می‌شوند تا رطوبت سطحی‌شان بدون تبخیر اسانس خشک شود.
            </p>
          </div>

          {/* Step 4 */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-full bg-[#2c3d28] text-white flex items-center justify-center font-bold text-xs">
                ۴
              </span>
              <Scissors className="w-5 h-5 text-[#3b5334]" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">
              خردکردن یکدست با تیغه‌های استاندارد
            </h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              خردکردن با ساطورهای فولادی مخصوص که برگ را برش می‌زند نه آنکه آن را له کند؛ نتیجه دانه‌های
              ریز و هماهنگ سبزی قورمه یا برش‌های درشت‌تر و خوش‌عطر سبزی کوکو و سبزی پلو است.
            </p>
          </div>

          {/* Step 5 */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-full bg-[#2c3d28] text-white flex items-center justify-center font-bold text-xs">
                ۵
              </span>
              <Flame className="w-5 h-5 text-[#8b2332]" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">
              سرخ‌کردن آرام در پاتیل مس
            </h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              سبزی قورمه خوشمزه‌ها با روغن ارده کنجد خالص و شعله بسیار ملایم به مدت بیش از ۳ ساعت تفت
              داده می‌شود تا به رنگ سبز تیره و روغن‌انداز اصیل برسد بدون آنکه تلخ یا سوخته گردد.
            </p>
          </div>

          {/* Step 6 */}
          <div className="bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-8 h-8 rounded-full bg-[#2c3d28] text-white flex items-center justify-center font-bold text-xs">
                ۶
              </span>
              <ChefHat className="w-5 h-5 text-[#3b5334]" />
            </div>
            <h3 className="font-extrabold text-base text-[#232724]">
              وکیوم بهداشتی و شوک سرمایی
            </h3>
            <p className="text-xs text-[#556052] leading-relaxed">
              بلافاصله پس از خنک‌شدن، در بسته‌های نیم و یک کیلویی وکیوم هواگیری‌شده بسته‌بندی شده و با
              دستگاه شوک سرمایی دمای آن پایین می‌آید تا بافت و عطر آن تا ماه‌ها تازه بماند.
            </p>
          </div>
        </div>
      </div>

      {/* Herb Varieties table / list */}
      <div className="bg-[#faf7f0] p-6 sm:p-8 rounded-3xl border border-[#ebe4d6] space-y-6">
        <h3 className="text-lg sm:text-xl font-bold text-[#232724]">
          انواع سبزیجات آماده قابل سفارش در کارگاه:
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-[#e5ded0] space-y-2">
            <h4 className="font-bold text-sm text-[#2c3d28]">سبزی قورمه سرخ‌شده اعلا</h4>
            <p className="text-xs text-[#697465]">
              تره، جعفری، گشنیز، اسفناج و شنبلیله بومی دورود تفت‌داده با روغن کنجد خالص.
            </p>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#e5ded0] space-y-2">
            <h4 className="font-bold text-sm text-[#2c3d28]">باقالی سبز دست‌پوست</h4>
            <p className="text-xs text-[#697465]">
              پوست اول و دوم کاملاً جداشده بدون له‌شدگی، آماده طبخ باقالی‌پلو با عطر شوید.
            </p>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#e5ded0] space-y-2">
            <h4 className="font-bold text-sm text-[#2c3d28]">سبزی کوکو تازه خردشده</h4>
            <p className="text-xs text-[#697465]">
              ترکیب تره تازه، گشنیز، جعفری و شوید با عطر تند سیر بهاره.
            </p>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#e5ded0] space-y-2">
            <h4 className="font-bold text-sm text-[#2c3d28]">سبزی پلو با ماهی</h4>
            <p className="text-xs text-[#697465]">
              تره، شوید، جعفri و ساقه سیر محلی خردشده به اندازه مناسب پلو.
            </p>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#e5ded0] space-y-2">
            <h4 className="font-bold text-sm text-[#2c3d28]">سبزی آش رشته و سوپ</h4>
            <p className="text-xs text-[#697465]">
              اسفناج برگ‌پهن، تره، گشنیز و جعفری خردشده سنتی درشت.
            </p>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#e5ded0] space-y-2">
            <h4 className="font-bold text-sm text-[#2c3d28]">شنبلیله خشک معطر هیزمی</h4>
            <p className="text-xs text-[#697465]">
              خشک‌شده در سایه با حفظ کامل رنگ سبز و بدون خاکه یا ساقه ضخیم.
            </p>
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-[#eee7da]">
          <p className="text-xs text-[#697465]">
            سفارش‌های حجم بالا یا نسبت‌های سفارشی برای مراسمات و نذورات خانوادگی پذیرفته می‌شود.
          </p>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate({ type: 'products', categorySlug: 'ready-herbs' })}
              className="px-5 py-2.5 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-full text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <span>خرید سبزیجات آماده</span>
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>

            <a
              href={`tel:${SITE_CONFIG.phone}`}
              className="px-4 py-2.5 bg-white border border-[#ded5c5] text-[#2c3d28] hover:bg-[#f2ede4] rounded-full text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>هماهنگی سفارش سفارشی</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
