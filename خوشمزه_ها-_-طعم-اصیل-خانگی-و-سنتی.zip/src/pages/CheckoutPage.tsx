import React, { useState } from 'react';
import {
  Send,
  CheckCircle2,
  Copy,
  ShoppingBag,
  Truck,
  ArrowRight,
  ShieldCheck,
  ExternalLink,
  MessageCircle,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { TELEGRAM_BOT_URL, SITE_CONFIG } from '../data/config';
import { PageView } from '../types';

interface CheckoutPageProps {
  onNavigate: (page: PageView) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ onNavigate }) => {
  const { items, totalPrice, clearCart } = useCart();

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [province, setProvince] = useState('لرستان');
  const [city, setCity] = useState('دورود');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [shippingMethod, setShippingMethod] = useState<'courier' | 'post' | 'tipax'>('post');

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [orderCode, setOrderCode] = useState('');
  const [generatedText, setGeneratedText] = useState('');
  const [copied, setCopied] = useState(false);

  // If no items and not submitted, redirect back to cart
  if (items.length === 0 && !isSubmitted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-[#232724]">سبد خرید شما خالی است</h2>
        <p className="text-xs text-[#717c6e]">ابتدا محصولاتی را به سبد خرید خود اضافه کنید.</p>
        <button
          onClick={() => onNavigate({ type: 'products' })}
          className="px-6 py-2.5 bg-[#2c3d28] text-white rounded-full text-xs font-bold"
        >
          مشاهده کاتالوگ محصولات
        </button>
      </div>
    );
  }

  const shippingCost = totalPrice >= SITE_CONFIG.freeShippingThreshold ? 0 : 45000;
  const grandTotal = totalPrice + shippingCost;

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim() || !phone.trim() || !address.trim()) {
      alert('لطفاً فیلدهای ضروری (نام، شماره تماس و آدرس) را تکمیل نمایید.');
      return;
    }

    const code = `KH-${Math.floor(10000 + Math.random() * 90000)}`;
    setOrderCode(code);

    const shippingTitles = {
      courier: 'پیک ویژه درون‌شهری (تهران و لرستان)',
      post: 'پست پیشتاز کشوری',
      tipax: 'تیپاکس فوری',
    };

    // Construct structured order message
    let text = `📦 سفارش جدید در مطبخ سنتی «خوشمزه‌ها»\n`;
    text += `کد سفارش: ${code}\n`;
    text += `─────────────\n`;
    text += `👤 نام مشتری: ${customerName}\n`;
    text += `📞 شماره تماس: ${phone}\n`;
    text += `📍 استان و شهر: ${province} - ${city}\n`;
    text += `🏠 آدرس پستی: ${address}\n`;
    text += `🚚 شیوه ارسال: ${shippingTitles[shippingMethod]}\n`;
    if (notes.trim()) {
      text += `📝 توضیحات مشتری: ${notes}\n`;
    }
    text += `─────────────\n`;
    text += `🛒 لیست محصولات:\n`;

    items.forEach((item, index) => {
      const linePrice = item.selectedSize.price * item.quantity;
      text += `${index + 1}. ${item.product.name} (${item.selectedSize.label}) × ${item.quantity} عدد = ${linePrice.toLocaleString('fa-IR')} تومان\n`;
    });

    text += `─────────────\n`;
    text += `💰 مجموع اقلام: ${totalPrice.toLocaleString('fa-IR')} تومان\n`;
    text += `📦 هزینه بسته‌بندی و ارسال: ${shippingCost === 0 ? 'رایگان' : `${shippingCost.toLocaleString('fa-IR')} تومان`}\n`;
    text += `💳 مبلغ کل نهایی: ${grandTotal.toLocaleString('fa-IR')} تومان\n`;
    text += `\nلطفاً جهت تأیید و ارسال سفارش با اینجانب هماهنگی فرمایید. سپاس`;

    setGeneratedText(text);
    setIsSubmitted(true);
    clearCart();

    // Open telegram bot link with message
    try {
      const tgUrl = `${TELEGRAM_BOT_URL}?text=${encodeURIComponent(text)}`;
      window.open(tgUrl, '_blank');
    } catch (e) {
      console.error('Could not open telegram url', e);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-[#717c6e]">
        <button
          onClick={() => onNavigate({ type: 'home' })}
          className="hover:text-[#2c3d28] transition-colors cursor-pointer"
        >
          صفحه اصلی
        </button>
        <span>/</span>
        <button
          onClick={() => onNavigate({ type: 'cart' })}
          className="hover:text-[#2c3d28] transition-colors cursor-pointer"
        >
          سبد خرید
        </button>
        <span>/</span>
        <span className="font-semibold text-[#2c3d28]">ثبت اطلاعات و نهایی‌سازی سفارش</span>
      </div>

      {isSubmitted ? (
        /* Order Confirmed Screen */
        <div className="max-w-3xl mx-auto bg-white p-6 sm:p-10 rounded-3xl border border-[#ebe4d6] shadow-sm space-y-6">
          <div className="text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-[#f0f6ec] text-[#3b5334] flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-[#232724]">
              سفارش شما با موفقیت ثبت گردید!
            </h1>
            <p className="text-xs sm:text-sm text-[#556052] max-w-lg mx-auto leading-relaxed">
              کد پیگیری اختصاصی شما: <span className="font-bold text-[#8b2332]">{orderCode}</span>
            </p>
          </div>

          {/* Telegram Action banner */}
          <div className="bg-[#fcfbf7] p-5 rounded-2xl border border-[#e8e2d4] space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-[#2c3d28]">
              <MessageCircle className="w-4 h-4 text-[#8b2332]" />
              <span>انتقال اطلاعات به بات پیام‌رسان تلگرام:</span>
            </div>
            <p className="text-xs text-[#6e7769] leading-relaxed">
              اطلاعات سفارش شما به صورت متن آماده شده است. با کلیک بر روی دکمه زیر، وارد بات تلگرام کارگاه
              می‌شوید و متن سفارش به صورت خودکار ارسال خواهد شد.
            </p>

            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <a
                href={`${TELEGRAM_BOT_URL}?text=${encodeURIComponent(generatedText)}`}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:flex-1 py-3.5 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-all"
              >
                <Send className="w-4 h-4" />
                <span>باز کردن بات تلگرام و ارسال فاکتور</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </a>

              <button
                onClick={copyToClipboard}
                className="w-full sm:w-auto px-4 py-3.5 bg-white border border-[#ded5c5] hover:bg-[#f3ede3] text-[#2c3d28] rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Copy className="w-4 h-4" />
                <span>{copied ? 'کپی شد!' : 'کپی متن سفارش'}</span>
              </button>
            </div>
          </div>

          {/* Invoice Summary Box */}
          <div className="space-y-3">
            <h3 className="font-bold text-xs text-[#717c6e]">خلاصه فاکتور ثبت‌شده:</h3>
            <pre className="bg-[#faf7f2] p-4 rounded-2xl border border-[#ded5c5] text-xs text-[#384033] font-mono leading-relaxed whitespace-pre-wrap overflow-x-auto text-right">
              {generatedText}
            </pre>
          </div>

          {/* Return button */}
          <div className="pt-4 border-t border-[#f2ede4] text-center">
            <button
              onClick={() => onNavigate({ type: 'home' })}
              className="px-6 py-2.5 bg-[#f5f1e8] hover:bg-[#eadecc] text-[#2c3d28] rounded-full text-xs font-bold transition-colors cursor-pointer"
            >
              بازگشت به صفحه اصلی
            </button>
          </div>
        </div>
      ) : (
        /* Checkout Form & Cart Overview */
        <form onSubmit={handleFinalSubmit} className="space-y-8">
          <div className="space-y-2 border-b border-[#ece5d8] pb-4">
            <h1 className="text-2xl sm:text-3xl font-black text-[#232724]">
              اطلاعات تحویل‌گیرنده و ثبت نهایی سفارش
            </h1>
            <p className="text-xs sm:text-sm text-[#667262]">
              پرداخت آنلاین در سایت وجود ندارد. پس از ثبت نهایی، سفارش شما به بات تلگرام کارگاه جهت
              هماهنگی زمان تحویل و شیوه ارسال منتقل می‌شود.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left: Input Fields Form (in RTL, Right is 7 cols) */}
            <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-6">
              <h2 className="font-bold text-base text-[#232724] border-b border-[#eee8dc] pb-3">
                مشخصات گیرنده مرسوله
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#353f32]">
                    نام و نام خانوادگی تحویل‌گیرنده: <span className="text-[#8b2332]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="مثال: نرگس رضایی"
                    className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#353f32]">
                    شماره تماس همراه: <span className="text-[#8b2332]">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="مثال: ۰۹۱۲۳۴۵۶۷۸۹"
                    className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#353f32]">استان:</label>
                  <input
                    type="text"
                    required
                    value={province}
                    onChange={(e) => setProvince(e.target.value)}
                    placeholder="مثال: تهران یا لرستان"
                    className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#353f32]">شهر:</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="مثال: تهران یا دورود"
                    className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-[#353f32]">
                  آدرس دقیق پستی: <span className="text-[#8b2332]">*</span>
                </label>
                <textarea
                  required
                  rows={3}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="خیابان، کوچه، پلاک، واحد..."
                  className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white resize-none"
                />
              </div>

              {/* Shipping method selection */}
              <div className="space-y-2.5">
                <label className="block text-xs font-bold text-[#353f32]">انتخاب شیوه ارسال:</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <label
                    className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-colors ${
                      shippingMethod === 'post'
                        ? 'border-[#2c3d28] bg-[#f0f6ec]'
                        : 'border-[#ded5c5] bg-white'
                    }`}
                  >
                    <input
                      type="radio"
                      name="shipping"
                      className="hidden"
                      checked={shippingMethod === 'post'}
                      onChange={() => setShippingMethod('post')}
                    />
                    <span className="font-bold text-xs text-[#232724]">پست پیشتاز کشوری</span>
                    <span className="text-[11px] text-[#717c6e] mt-1">۲ الی ۴ روز کاری</span>
                  </label>

                  <label
                    className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-colors ${
                      shippingMethod === 'tipax'
                        ? 'border-[#2c3d28] bg-[#f0f6ec]'
                        : 'border-[#ded5c5] bg-white'
                    }`}
                  >
                    <input
                      type="radio"
                      name="shipping"
                      className="hidden"
                      checked={shippingMethod === 'tipax'}
                      onChange={() => setShippingMethod('tipax')}
                    />
                    <span className="font-bold text-xs text-[#232724]">تیپاکس فوری</span>
                    <span className="text-[11px] text-[#717c6e] mt-1">۲۴ الی ۴۸ ساعته</span>
                  </label>

                  <label
                    className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-colors ${
                      shippingMethod === 'courier'
                        ? 'border-[#2c3d28] bg-[#f0f6ec]'
                        : 'border-[#ded5c5] bg-white'
                    }`}
                  >
                    <input
                      type="radio"
                      name="shipping"
                      className="hidden"
                      checked={shippingMethod === 'courier'}
                      onChange={() => setShippingMethod('courier')}
                    />
                    <span className="font-bold text-xs text-[#232724]">پیک شهری ویژه</span>
                    <span className="text-[11px] text-[#717c6e] mt-1">تهران و لرستان</span>
                  </label>
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-[#353f32]">
                  توضیحات و یادداشت سفارش (اختیاری):
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="مثال: لطفاً قبل از ارسال تماس گرفته شود یا میزان تندی کمتر باشد..."
                  className="w-full px-3.5 py-2.5 bg-[#fcfbf7] border border-[#ded5c5] rounded-xl text-xs sm:text-sm focus:outline-none focus:border-[#2c3d28] focus:bg-white"
                />
              </div>
            </div>

            {/* Right: Order Summary Sidebar (5 cols) */}
            <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-[#ebe4d6] shadow-xs space-y-5 sticky top-24">
              <h2 className="font-bold text-base text-[#232724] border-b border-[#eee8dc] pb-3">
                مرور اقلام سفارش ({items.length} محصول)
              </h2>

              <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                {items.map((item) => (
                  <div
                    key={`${item.product.id}-${item.selectedSize.label}`}
                    className="flex items-center justify-between text-xs py-1.5 border-b border-[#f6f2ea] last:border-0"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-10 h-10 rounded-lg object-cover border border-[#eee8dc]"
                      />
                      <div>
                        <span className="font-bold text-[#232724] block line-clamp-1">
                          {item.product.name}
                        </span>
                        <span className="text-[10px] text-[#717c6e]">
                          {item.selectedSize.label} × {item.quantity} عدد
                        </span>
                      </div>
                    </div>

                    <span className="font-bold text-[#232724]">
                      {(item.selectedSize.price * item.quantity).toLocaleString('fa-IR')} تومان
                    </span>
                  </div>
                ))}
              </div>

              {/* Price Calculations */}
              <div className="pt-3 border-t border-[#f2ede4] space-y-2 text-xs text-[#556052]">
                <div className="flex items-center justify-between">
                  <span>مجموع اقلام:</span>
                  <span className="font-bold text-[#232724]">
                    {totalPrice.toLocaleString('fa-IR')} تومان
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span>هزینه بسته‌بندی ایمن و ارسال:</span>
                  <span>
                    {shippingCost === 0 ? (
                      <span className="text-[#3b5334] font-bold">رایگان</span>
                    ) : (
                      `${shippingCost.toLocaleString('fa-IR')} تومان`
                    )}
                  </span>
                </div>

                <div className="pt-2 border-t border-[#f2ede4] flex items-center justify-between text-sm">
                  <span className="font-bold text-[#232724]">مجموع نهایی سفارش:</span>
                  <span className="font-black text-lg text-[#8b2332]">
                    {grandTotal.toLocaleString('fa-IR')} تومان
                  </span>
                </div>
              </div>

              {/* Telegram Notice */}
              <div className="bg-[#fcfbf7] p-3 rounded-xl border border-[#ebe4d6] text-[11px] text-[#717c6e] leading-relaxed">
                🚀 با فشردن دکمه زیر، سفارش شما ثبت شده و مستقیماً به بات تلگرام{' '}
                <span className="font-mono text-[#2c3d28]">«خوشمزه‌ها»</span> ارسال می‌گردد.
              </div>

              {/* Final Submit Button */}
              <button
                type="submit"
                className="w-full py-4 bg-[#8b2332] hover:bg-[#a02c3c] text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>ثبت نهایی سفارش</span>
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};
