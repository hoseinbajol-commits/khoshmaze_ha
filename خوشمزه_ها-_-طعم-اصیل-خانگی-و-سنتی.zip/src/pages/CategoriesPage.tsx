import React from 'react';
import { ArrowLeft, Sparkles, FolderTree } from 'lucide-react';
import { CATEGORIES, PRODUCTS } from '../data/products';
import { PageView } from '../types';

interface CategoriesPageProps {
  onNavigate: (page: PageView) => void;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-10">
      {/* Breadcrumb & Header */}
      <div className="space-y-2 border-b border-[#ece5d8] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">دسته‌بندی‌های محصولات</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#232724]">
          دسته‌بندی‌های خوشمزه‌ها
        </h1>
        <p className="text-xs sm:text-sm text-[#667262] max-w-2xl leading-relaxed">
          کاوش در میان بخش‌های گوناگون مطبخ؛ از رب‌ها و چاشنی‌های هیزمی تا ترشی‌های جاافتاده و سبزیجات
          دست‌پاک‌کرده بهاره و پاییزه.
        </p>
      </div>

      {/* Categories Detailed Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {CATEGORIES.map((cat) => {
          const catProducts = PRODUCTS.filter((p) => p.categorySlug === cat.slug);

          return (
            <div
              key={cat.id}
              className="bg-white rounded-3xl border border-[#ebe4d6] overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-[#f3eee4]">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                <div className="absolute bottom-5 right-5 left-5 text-white">
                  <span className="bg-[#8b2332] text-[11px] font-bold px-2.5 py-0.5 rounded-full mb-2 inline-block">
                    {cat.productCount} محصول پخت خانگی
                  </span>
                  <h2 className="text-xl sm:text-2xl font-black">{cat.name}</h2>
                  <p className="text-xs text-[#e6ded2] mt-1 line-clamp-1">{cat.tagline}</p>
                </div>
              </div>

              <div className="p-6 space-y-4">
                <p className="text-xs sm:text-sm text-[#556052] leading-relaxed">
                  {cat.description}
                </p>

                {/* Sub-products preview pills */}
                {catProducts.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-[#f2ece0]">
                    <span className="text-[11px] font-bold text-[#717c6e] block">
                      برخی خوراکی‌های این دسته:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {catProducts.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => onNavigate({ type: 'product-detail', productId: p.id })}
                          className="text-[11px] bg-[#f7f4ee] hover:bg-[#ede6d8] text-[#2c3d28] font-medium px-2.5 py-1 rounded-lg border border-[#e4ded0] transition-colors"
                        >
                          {p.name}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-2">
                  <button
                    onClick={() => onNavigate({ type: 'products', categorySlug: cat.slug })}
                    className="w-full py-3 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer"
                  >
                    <span>مشاهده محصولات دسته «{cat.name}»</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
