import React from 'react';
import { Leaf, Calendar, Sparkles, ArrowLeft, Sun, Snowflake, CheckCircle2 } from 'lucide-react';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/common/ProductCard';
import { PageView } from '../types';

interface SeasonalPageProps {
  onNavigate: (page: PageView) => void;
}

export const SeasonalPage: React.FC<SeasonalPageProps> = ({ onNavigate }) => {
  const seasonalProducts = PRODUCTS.filter((p) => p.isSeasonal);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12 text-right space-y-12">
      {/* Breadcrumb & Header */}
      <div className="space-y-3 border-b border-[#ece5d8] pb-6">
        <div className="flex items-center gap-2 text-xs text-[#717c6e]">
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="hover:text-[#2c3d28] transition-colors cursor-pointer"
          >
            صفحه اصلی
          </button>
          <span>/</span>
          <span className="font-semibold text-[#2c3d28]">محصولات این فصل (نوبارانه‌ها)</span>
        </div>

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#fbf0e8] text-[#8b2332] text-xs font-bold border border-[#f2d8cd]">
          <Calendar className="w-3.5 h-3.5" />
          <span>تقویم برداشت و پخت نوبارانه‌های کارگاه</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-black text-[#232724]">
          محصولات این فصل؛ احترام به چرخه طبیعی طبیعت
        </h1>

        <p className="text-xs sm:text-sm text-[#5f6b5b] max-w-3xl leading-relaxed">
          ما هیچ گیاه یا صیفی‌جاتی را به شکل فله‌ای و منجمد چندساله انبار نمی‌کنیم. هر فصل که از راه
          می‌رسد، مطبخ کارگاه خوشمزه‌ها رنگ و بوی نوبارانه همان فصل را به خود می‌گیرد؛ از انار یاقوتی
          پاییز گرفته تا باقالی‌های لطیف بهاره.
        </p>
      </div>

      {/* Season Cards Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Autumn & Winter */}
        <div className="bg-gradient-to-br from-[#faf4ee] to-[#f0e3d5] p-6 sm:p-7 rounded-3xl border border-[#e4d4c5] space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="bg-[#8b2332] text-white text-xs font-bold px-3 py-1 rounded-full">
              فصل جاری: پاییز و زمستان
            </span>
            <Snowflake className="w-5 h-5 text-[#8b2332]" />
          </div>

          <h2 className="text-xl font-extrabold text-[#232724]">
            فصل دیگ‌های جوشان انار و ترخینه‌های کوهستان
          </h2>

          <p className="text-xs sm:text-sm text-[#5a4d43] leading-relaxed">
            در این فصل، بوی چوب و آتش هیزمی در کنار دیگ‌های مس رب انار ساوه می‌پیچد. ترخینه‌های آفتاب‌پز
            آماده گرم کردن شب‌های سردند و ترشی‌های هفت‌بیجار به اوج جاافتادگی و تردی خود رسیده‌اند.
          </p>

          <div className="pt-2 flex flex-wrap gap-2 text-xs text-[#2c3d28]">
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-[#e2d5c6]">
              • رب انار ملس ساوه
            </span>
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-[#e2d5c6]">
              • ترخینه دوغی با پونه وحشی
            </span>
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-[#e2d5c6]">
              • ترشی هفت‌بیجار جاافتاده
            </span>
          </div>
        </div>

        {/* Spring & Summer */}
        <div className="bg-gradient-to-br from-[#edf4ea] to-[#dcead6] p-6 sm:p-7 rounded-3xl border border-[#c9ddc2] space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="bg-[#2c3d28] text-white text-xs font-bold px-3 py-1 rounded-full">
              بهار و تابستان
            </span>
            <Sun className="w-5 h-5 text-[#4e6b39]" />
          </div>

          <h2 className="text-xl font-extrabold text-[#232724]">
            فصل عطر سبزی‌های نوبرانه و آبغوره تازه
          </h2>

          <p className="text-xs sm:text-sm text-[#44563b] leading-relaxed">
            با شروع اردیبهشت، باقالی سبز پوست‌دوم‌گرفته با عطر شوید تازه آماده باقالی‌پلو می‌شود و در
            مردادماه، غوره عسکری دست‌افشار با زلالی بلورین بدون حتی یک قطره آب افزوده به شیشه کشیده
            می‌شود.
          </p>

          <div className="pt-2 flex flex-wrap gap-2 text-xs text-[#2c3d28]">
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-[#c8dec0]">
              • باقالی سبز دست‌پوست
            </span>
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-[#c8dec0]">
              • آبغوره طبیعی عسکری
            </span>
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-[#c8dec0]">
              • خیارشور قلمی بوته‌ای
            </span>
          </div>
        </div>
      </div>

      {/* Seasonal Products Grid */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-xl sm:text-2xl font-bold text-[#232724]">
            فهرست محصولات نوبارانه موجود در کارگاه
          </h3>
          <span className="text-xs text-[#717c6e]">پخت و آماده‌سازی محدود روزانه</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {seasonalProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onNavigate={(id) => onNavigate({ type: 'product-detail', productId: id })}
            />
          ))}
        </div>
      </div>

      {/* Guarantee Section */}
      <div className="bg-[#faf7f0] p-6 sm:p-8 rounded-3xl border border-[#ebe4d6] flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-right">
          <h4 className="font-extrabold text-base text-[#232724]">
            چرا نوبارانه‌های خوشمزه‌ها تکرارنشدنی هستند؟
          </h4>
          <p className="text-xs text-[#636e5f] max-w-2xl leading-relaxed">
            چون هرگز میوه فریزری یا رب سال گذشته تحویل داده نمی‌شود. محصول هر فصل مختص همان ایام است و
            پس از اتمام موجودی پخت پاییزه، باید تا رویش دوباره باغ‌ها در فصل بعد منتظر ماند.
          </p>
        </div>

        <button
          onClick={() => onNavigate({ type: 'products' })}
          className="px-6 py-3 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-full text-xs font-bold transition-all shrink-0 flex items-center gap-2 cursor-pointer shadow-xs"
        >
          <span>مشاهده تمامی محصولات کارگاه</span>
          <ArrowLeft className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
