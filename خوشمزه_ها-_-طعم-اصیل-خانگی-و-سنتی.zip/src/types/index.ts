export interface SizeOption {
  label: string; // e.g. "۵۰۰ گرمی" or "۱ کیلوگرمی"
  description?: string; // e.g. "شیشه متوسط خانگی"
  price: number; // e.g. 135000
  originalPrice?: number;
  badge?: string; // e.g. "صرفه‌جویی"
}

export interface ProductAttribute {
  label: string;
  value: string;
}

export interface ProductReview {
  id: string;
  author: string;
  location?: string;
  rating: number;
  date: string;
  comment: string;
  verifiedPurchase?: boolean;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category: string; // e.g. "رب‌ها و چاشنی‌ها"
  categorySlug: string;
  shortDescription: string;
  fullDescription: string;
  storyDescription?: string;
  ingredients?: string[];
  properties?: string[];
  basePrice: number;
  sizes: SizeOption[];
  images: string[];
  badge?: string; // e.g. "نوبارانه پرطرفدار پاییز و زمستان", "جاافتاده سنتی"
  rating: number;
  reviewsCount: number;
  inStock: boolean;
  stockStatusText: string;
  isSeasonal: boolean;
  seasonTag?: string;
  attributes: ProductAttribute[];
  craftCode: string; // e.g. "KH-782"
  origin: string; // e.g. "انار ساوه (باغستان)"
  nature: string; // e.g. "معتدل مایل به سرد"
  cookTime: string; // e.g. "۱۸ ساعت پیوسته"
  shelfLife: string; // e.g. "۱۲ ماه در جای خنک"
  storageAdvice?: string[];
  suggestedPairingIds?: string[];
}

export interface CartItem {
  product: Product;
  selectedSize: SizeOption;
  quantity: number;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  image: string;
  iconName?: string;
  productCount: number;
  featured?: boolean;
}

export interface OrderFormState {
  fullName: string;
  phone: string;
  province: string;
  city: string;
  address: string;
  postalCode?: string;
  notes?: string;
  shippingMethod: 'courier' | 'post' | 'tipax' | 'cold_delivery';
}

export type PageView =
  | { type: 'home' }
  | { type: 'products'; categorySlug?: string; seasonalOnly?: boolean }
  | { type: 'categories' }
  | { type: 'product-detail'; productId: string }
  | { type: 'seasonal' }
  | { type: 'packaging' }
  | { type: 'services' }
  | { type: 'about' }
  | { type: 'contact' }
  | { type: 'cart' }
  | { type: 'checkout' }
  | { type: 'order-confirmed'; orderId: string; orderData: OrderFormState; items: CartItem[]; totalAmount: number };
