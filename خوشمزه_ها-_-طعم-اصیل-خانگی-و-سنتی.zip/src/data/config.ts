/**
 * پیکربندی اصلی وب‌سایت و فروشگاه خانگی «خوشمزه‌ها»
 */

// آدرس بات تلگرام جهت ارسال و هماهنگی نهایی سفارشات
// در صورت نیاز به تغییر، این متغیر را با آدرس بات کارگاه جایگزین نمایید.
export const TELEGRAM_BOT_URL = "https://t.me/khoshmazeha_bot";

export const SITE_CONFIG = {
  brandName: "خوشمزه‌ها",
  brandSubtitle: "طعم اصیل خانگی و سنتی",
  tagline: "مطبخ اصیل دست‌پخت‌های ناب محلی و کارگاه سنتی",
  phone: "09167946965",
  phoneDisplay: "۰۹۱۶۷۹۴۶۹۶۵",
  landline: "02188884321",
  landlineDisplay: "۰۲۱-۸۸۸۸۴۳۲۱",
  secondaryPhone: "09123456789",
  secondaryPhoneDisplay: "۰۹۱۲۳۴۵۶۷۸۹",
  email: "hosein.bajol@gmail.com",
  secondaryEmail: "salam@khoshmazeha.ir",
  address: "لرستان، شهرستان دورود، کوی حکمت، کارگاه و مطبخ مرکزی خوشمزه‌ها",
  tajrishAddress: "تهران، میدان تجریش، بازارچه سنتی، پلاک ۲۴ (شوروم معرفی)",
  workingHours: "شنبه تا پنج‌شنبه: ۸:۰۰ صبح الی ۲۰:۰۰ شب",
  announcementTop: "ارسال روزانه محصولات تازه با بسته‌بندی بهداشتی سنتی و ارگانیک به سراسر کشور",
  announcementSeasonal: "نوشیدنی‌های طبیعی، ترشیجات تازه و محصولات نوبارانه فصل با ارسال سریع در بسته‌بندی سنتی",
  supportText: "تضمین سلامت و طعم خانگی",
  freeShippingThreshold: 500000, // ارسال رایگان برای سفارش‌های بالای ۵۰۰ هزار تومان
};
