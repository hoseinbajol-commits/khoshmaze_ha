import React, { useState } from 'react';
import { Phone, ShoppingBag, User, Menu, X, Truck, ShieldCheck, ChevronLeft } from 'lucide-react';
import { Logo } from '../common/Logo';
import { useCart } from '../../context/CartContext';
import { SITE_CONFIG } from '../../data/config';
import { PageView } from '../../types';

interface HeaderProps {
  currentPage: PageView;
  setCurrentPage: (page: PageView) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, setCurrentPage }) => {
  const { totalCount, setIsCartDrawerOpen } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: 'صفحه اصلی', page: { type: 'home' } as PageView, activeKey: 'home' },
    { label: 'کاتالوگ محصولات', page: { type: 'products' } as PageView, activeKey: 'products' },
    { label: 'محصولات این فصل', page: { type: 'seasonal' } as PageView, activeKey: 'seasonal' },
    { label: 'خدمات آماده‌سازی سبزی', page: { type: 'services' } as PageView, activeKey: 'services' },
    { label: 'بسته‌بندی و ارسال', page: { type: 'packaging' } as PageView, activeKey: 'packaging' },
    { label: 'درباره ما', page: { type: 'about' } as PageView, activeKey: 'about' },
    { label: 'تماس', page: { type: 'contact' } as PageView, activeKey: 'contact' },
  ];

  const isCurrentActive = (activeKey: string) => {
    if (currentPage.type === 'product-detail' && activeKey === 'products') return true;
    if (currentPage.type === 'categories' && activeKey === 'products') return true;
    return currentPage.type === activeKey;
  };

  const handleNavClick = (page: PageView) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md shadow-xs border-b border-[#ece6da]">
      {/* Top Announcement Bar */}
      <div className="bg-[#2c3d28] text-white text-xs py-2 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Announcement text */}
          <div className="flex items-center gap-2 truncate">
            <Truck className="w-3.5 h-3.5 text-[#c6dbb8] shrink-0" />
            <span className="truncate font-light text-[11.5px] sm:text-xs">
              {SITE_CONFIG.announcementTop}
            </span>
          </div>

          {/* Contact & Guarantee */}
          <div className="hidden md:flex items-center gap-5 text-[11.5px] text-[#e0ecd6] font-medium shrink-0">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#a8cf92]" />
              {SITE_CONFIG.supportText}
            </span>
            <span className="opacity-40">|</span>
            <a
              href={`tel:${SITE_CONFIG.landline}`}
              className="hover:text-white transition-colors flex items-center gap-1"
            >
              <span>پشتیبانی سفارشات:</span>
              <span className="font-bold tracking-wider">{SITE_CONFIG.landlineDisplay}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
        {/* Right: Brand & Logo */}
        <div
          onClick={() => handleNavClick({ type: 'home' })}
          className="cursor-pointer group flex items-center gap-3 shrink-0"
        >
          <Logo size={42} showText={true} />
        </div>

        {/* Center: Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navItems.map((item) => {
            const active = isCurrentActive(item.activeKey);
            return (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.page)}
                className={`text-xs xl:text-[13px] transition-all duration-200 cursor-pointer ${
                  active
                    ? 'bg-[#2c3d28] text-white font-semibold px-3.5 py-1.5 rounded-full shadow-xs'
                    : 'text-[#384234] hover:text-[#2c3d28] font-medium px-3 py-1.5 rounded-full hover:bg-[#f5f2ea]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Left: Actions (Call, Cart, Profile, Mobile Menu) */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          {/* Quick Call Button */}
          <a
            href={`tel:${SITE_CONFIG.phone}`}
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full border border-[#ded5c5] bg-[#faf7f0] text-xs font-semibold text-[#2c3d28] hover:bg-[#2c3d28] hover:text-white hover:border-[#2c3d28] transition-all duration-200"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>تماس سریع</span>
          </a>

          {/* Cart Button with Count Badge */}
          <button
            onClick={() => setIsCartDrawerOpen(true)}
            className="relative p-2 rounded-full border border-[#e2dacf] bg-[#faf7f2] text-[#2c3d28] hover:bg-[#2c3d28] hover:text-white transition-all cursor-pointer"
            aria-label="سبد خرید"
          >
            <ShoppingBag className="w-5 h-5" />
            {totalCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#8b2332] text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-xs">
                {totalCount.toLocaleString('fa-IR')}
              </span>
            )}
          </button>

          {/* User Profile icon */}
          <button
            onClick={() => handleNavClick({ type: 'contact' })}
            className="p-2 rounded-full border border-[#e2dacf] bg-[#faf7f2] text-[#556052] hover:text-[#2c3d28] hover:bg-[#f0ebe0] transition-colors"
            aria-label="حساب کاربری یا راهنما"
          >
            <User className="w-5 h-5" />
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-[#303c2c] hover:bg-[#f3ede3] transition-colors"
            aria-label="منوی سایت"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#ebe4d7] bg-[#fbf9f4] px-4 py-4 space-y-2 shadow-inner animate-in slide-in-from-top-2">
          {navItems.map((item) => {
            const active = isCurrentActive(item.activeKey);
            return (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.page)}
                className={`w-full text-right px-4 py-2.5 rounded-xl text-sm font-medium transition-all flex items-center justify-between ${
                  active
                    ? 'bg-[#2c3d28] text-white font-semibold'
                    : 'text-[#384234] hover:bg-[#f0ebe0]'
                }`}
              >
                <span>{item.label}</span>
                <ChevronLeft className="w-4 h-4 opacity-70" />
              </button>
            );
          })}

          <div className="pt-3 border-t border-[#e8e0d1] flex flex-col gap-2">
            <a
              href={`tel:${SITE_CONFIG.phone}`}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#2c3d28] text-white font-semibold text-xs shadow-xs"
            >
              <Phone className="w-4 h-4" />
              <span>تماس مستقیم با کارگاه ({SITE_CONFIG.phoneDisplay})</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
