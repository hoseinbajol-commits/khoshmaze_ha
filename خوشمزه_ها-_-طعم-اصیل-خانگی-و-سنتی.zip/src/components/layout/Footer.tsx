import React from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  ShieldCheck,
  Sparkles,
  RotateCcw,
  PackageCheck,
  Heart,
} from 'lucide-react';
import { Logo } from '../common/Logo';
import { SITE_CONFIG } from '../../data/config';
import { PageView } from '../../types';

interface FooterProps {
  onNavigate: (page: PageView) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#f5f1e8] text-[#2c342b] border-t border-[#e2dbce] pt-14 pb-8 text-right">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Main 4 Columns Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-[#e1d9cc]">
          {/* Col 1: Brand Info */}
          <div className="space-y-4">
            <div
              onClick={() => onNavigate({ type: 'home' })}
              className="cursor-pointer inline-flex items-center gap-2"
            >
              <Logo size={42} showText={true} />
            </div>

            <p className="text-xs text-[#525e4e] leading-relaxed">
              {SITE_CONFIG.brandName}: مطبخ اصیل دست‌پخت‌های ناب محلی. پلتفرم تخصصی عرضه محصولات غذایی
              دست‌چین، خانگی، مرباجات نوبارانه، ترشی‌های هفت‌بیجار و سبزیجات تازه آماده‌سازی‌شده با
              رعایت استانداردهای سنتی و بهداشتی اصیل ایرانی.
            </p>

            {/* Badges */}
            <div className="flex items-center gap-2 pt-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e8e2d4] text-[#2c3d28] text-xs font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-[#547346]" />
                ۱۰۰٪ ارگانیک
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e8e2d4] text-[#8b2332] text-xs font-semibold">
                <Heart className="w-3.5 h-3.5 fill-current" />
                پخت خانگی
              </span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="font-bold text-sm text-[#232724] mb-4 pb-1 border-b border-[#ded5c5] inline-block">
              دسترس‌های سریع
            </h4>
            <ul className="space-y-2.5 text-xs text-[#525e4e]">
              <li>
                <button
                  onClick={() => onNavigate({ type: 'products' })}
                  className="hover:text-[#8b2332] hover:translate-x-[-2px] transition-all cursor-pointer"
                >
                  کاتالوگ کامل خوراکی‌های خانگی
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'seasonal' })}
                  className="hover:text-[#8b2332] hover:translate-x-[-2px] transition-all cursor-pointer"
                >
                  نوبارها و طعم‌های این فصل
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'services' })}
                  className="hover:text-[#8b2332] hover:translate-x-[-2px] transition-all cursor-pointer"
                >
                  سبزی قورمه، کوکو و پلوئی تازه خردشده
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'packaging' })}
                  className="hover:text-[#8b2332] hover:translate-x-[-2px] transition-all cursor-pointer"
                >
                  شیوه بسته‌بندی در شیشه و ارسال خنک
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'about' })}
                  className="hover:text-[#8b2332] hover:translate-x-[-2px] transition-all cursor-pointer"
                >
                  داستان خوشمزه‌ها و کارگاه مادرانه
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact Details */}
          <div>
            <h4 className="font-bold text-sm text-[#232724] mb-4 pb-1 border-b border-[#ded5c5] inline-block">
              پل‌های ارتباطی دکان
            </h4>
            <ul className="space-y-3 text-xs text-[#525e4e]">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#607753] shrink-0 mt-0.5" />
                <span>{SITE_CONFIG.address}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#607753] shrink-0" />
                <div className="flex items-center gap-2">
                  <a href={`tel:${SITE_CONFIG.phone}`} className="hover:text-[#2c3d28] font-semibold">
                    {SITE_CONFIG.phoneDisplay}
                  </a>
                  <span>/</span>
                  <a href={`tel:${SITE_CONFIG.landline}`} className="hover:text-[#2c3d28]">
                    {SITE_CONFIG.landlineDisplay}
                  </a>
                </div>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#607753] shrink-0" />
                <a href={`mailto:${SITE_CONFIG.email}`} className="hover:text-[#2c3d28]">
                  {SITE_CONFIG.email}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#607753] shrink-0" />
                <span>{SITE_CONFIG.workingHours}</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Trust & Guarantees */}
          <div>
            <h4 className="font-bold text-sm text-[#232724] mb-4 pb-1 border-b border-[#ded5c5] inline-block">
              ضمانت اصالت و سلامت
            </h4>
            <div className="grid grid-cols-2 gap-2.5">
              <div className="bg-white/80 p-2.5 rounded-xl border border-[#e5dfd2] flex flex-col items-center text-center">
                <Sparkles className="w-5 h-5 text-[#3b5334] mb-1" />
                <span className="font-bold text-[11px] text-[#2c3d28]">مواد اولیه تازه</span>
                <span className="text-[10px] text-[#717c6e]">بدون افزودنی شیمیایی</span>
              </div>

              <div className="bg-white/80 p-2.5 rounded-xl border border-[#e5dfd2] flex flex-col items-center text-center">
                <ShieldCheck className="w-5 h-5 text-[#3b5334] mb-1" />
                <span className="font-bold text-[11px] text-[#2c3d28]">بهداشت معتبر</span>
                <span className="text-[10px] text-[#717c6e]">نظارت کامل پخت</span>
              </div>

              <div className="bg-white/80 p-2.5 rounded-xl border border-[#e5dfd2] flex flex-col items-center text-center">
                <RotateCcw className="w-5 h-5 text-[#3b5334] mb-1" />
                <span className="font-bold text-[11px] text-[#2c3d28]">ضمانت بازگشت</span>
                <span className="text-[10px] text-[#717c6e]">رضایت کامل از طعم</span>
              </div>

              <div className="bg-white/80 p-2.5 rounded-xl border border-[#e5dfd2] flex flex-col items-center text-center">
                <PackageCheck className="w-5 h-5 text-[#3b5334] mb-1" />
                <span className="font-bold text-[11px] text-[#2c3d28]">بسته‌بندی ایمن</span>
                <span className="text-[10px] text-[#717c6e]">ظروف پلمپ</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-[#717c6e] gap-4">
          <p>© ۱۴۰۳ تمامی حقوق مادی و معنوی متعلق به کارگاه سنتی «خوشمزه‌ها» می‌باشد.</p>

          <div className="flex items-center gap-4">
            <button
              onClick={() => onNavigate({ type: 'packaging' })}
              className="hover:text-[#2c3d28] transition-colors cursor-pointer"
            >
              شیوه‌نامه ارسال
            </button>
            <span>•</span>
            <button
              onClick={() => onNavigate({ type: 'about' })}
              className="hover:text-[#2c3d28] transition-colors cursor-pointer"
            >
              حریم خصوصی
            </button>
            <span>•</span>
            <button
              onClick={() => onNavigate({ type: 'contact' })}
              className="hover:text-[#2c3d28] transition-colors cursor-pointer"
            >
              پاسخ به پرسش‌ها
            </button>
          </div>

          <span className="text-[#8b2332] font-semibold text-[11.5px]">
            دست‌پخت ایرانی با مهر و اصالت
          </span>
        </div>
      </div>
    </footer>
  );
};
