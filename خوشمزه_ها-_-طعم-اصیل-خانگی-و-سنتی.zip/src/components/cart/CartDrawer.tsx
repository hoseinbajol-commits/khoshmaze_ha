import React from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { PageView } from '../../types';
import { SITE_CONFIG } from '../../data/config';

interface CartDrawerProps {
  onNavigate: (page: PageView) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onNavigate }) => {
  const {
    items,
    isCartDrawerOpen,
    setIsCartDrawerOpen,
    removeFromCart,
    updateQuantity,
    totalPrice,
    totalCount,
  } = useCart();

  if (!isCartDrawerOpen) return null;

  const handleCheckoutClick = () => {
    setIsCartDrawerOpen(false);
    onNavigate({ type: 'checkout' });
  };

  const handleViewCatalog = () => {
    setIsCartDrawerOpen(false);
    onNavigate({ type: 'products' });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden text-right">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartDrawerOpen(false)}
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity duration-300"
      />

      {/* Drawer Panel */}
      <div className="absolute inset-y-0 left-0 max-w-full flex pl-0 sm:pl-10">
        <div className="w-screen max-w-md bg-[#faf8f4] shadow-2xl flex flex-col justify-between border-r border-[#e8e2d5]">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-[#e8e2d5] bg-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#2c3d28]" />
              <h3 className="font-bold text-base text-[#232724]">سبد خرید شما</h3>
              <span className="text-xs bg-[#e8e2d5] text-[#2c3d28] font-bold px-2 py-0.5 rounded-full">
                {totalCount.toLocaleString('fa-IR')} قلم
              </span>
            </div>

            <button
              onClick={() => setIsCartDrawerOpen(false)}
              className="p-1.5 rounded-lg text-[#657062] hover:bg-[#f0ece2] transition-colors cursor-pointer"
              aria-label="بستن"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#f0eae0] flex items-center justify-center text-[#8e988b]">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-base text-[#2c342b]">سبد خرید شما هنوز خالی است</h4>
                <p className="text-xs text-[#717c6e] max-w-xs leading-relaxed">
                  چاشنی‌ها، ترشی‌های هفت‌بیجار، رب انار دست‌ساز و سبزیجات تازه آماده‌سازی‌شده کارگاه
                  منتظر سفره شما هستند.
                </p>
                <button
                  onClick={handleViewCatalog}
                  className="mt-2 px-5 py-2.5 bg-[#2c3d28] text-white text-xs font-semibold rounded-full hover:bg-[#3d5238] transition-colors shadow-xs"
                >
                  مشاهده کاتالوگ محصولات خانگی
                </button>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedSize.label}`}
                  className="bg-white p-3.5 rounded-2xl border border-[#ebe4d6] shadow-xs flex gap-3 items-center justify-between"
                >
                  {/* Thumbnail */}
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-xl object-cover border border-[#eee8dc] shrink-0"
                  />

                  {/* Info */}
                  <div className="flex-1 min-w-0 pr-1">
                    <h5 className="font-bold text-xs sm:text-sm text-[#232724] truncate">
                      {item.product.name}
                    </h5>
                    <span className="text-[11px] text-[#717c6e] block mt-0.5">
                      {item.selectedSize.label}
                    </span>
                    <div className="flex items-center gap-1 mt-1 text-xs font-bold text-[#8b2332]">
                      <span>{(item.selectedSize.price * item.quantity).toLocaleString('fa-IR')}</span>
                      <span className="text-[10px] text-[#697266] font-normal">تومان</span>
                    </div>
                  </div>

                  {/* Quantity Stepper & Remove */}
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <button
                      onClick={() =>
                        removeFromCart(item.product.id, item.selectedSize.label)
                      }
                      className="text-[#9ea79b] hover:text-[#8b2332] p-1 transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center gap-1.5 bg-[#f5f1e8] rounded-lg p-1 border border-[#ded5c5]">
                      <button
                        onClick={() =>
                          updateQuantity(
                            item.product.id,
                            item.selectedSize.label,
                            item.quantity + 1
                          )
                        }
                        className="w-5 h-5 flex items-center justify-center rounded bg-white text-[#2c3d28] hover:bg-[#e4ddcf] transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold w-4 text-center">
                        {item.quantity.toLocaleString('fa-IR')}
                      </span>
                      <button
                        onClick={() =>
                          updateQuantity(
                            item.product.id,
                            item.selectedSize.label,
                            item.quantity - 1
                          )
                        }
                        className="w-5 h-5 flex items-center justify-center rounded bg-white text-[#2c3d28] hover:bg-[#e4ddcf] transition-colors"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout button */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 bg-white border-t border-[#e8e2d5] space-y-3">
              {/* Free shipping threshold progress */}
              <div className="bg-[#f7f4ee] p-2.5 rounded-xl border border-[#ebe5da] text-xs">
                {totalPrice >= SITE_CONFIG.freeShippingThreshold ? (
                  <p className="text-[#2c3d28] font-bold text-center">
                    🎉 تبریک! سفارش شما مشمول ارسال رایگان شد.
                  </p>
                ) : (
                  <p className="text-[#657062] text-center">
                    فقط{' '}
                    <span className="font-bold text-[#8b2332]">
                      {(SITE_CONFIG.freeShippingThreshold - totalPrice).toLocaleString('fa-IR')}{' '}
                      تومان
                    </span>{' '}
                    دیگر تا ارسال رایگان
                  </p>
                )}
              </div>

              {/* Total Row */}
              <div className="flex items-center justify-between text-sm pt-1">
                <span className="text-[#657062] font-medium">مجموع اقلام:</span>
                <div className="flex items-center gap-1">
                  <span className="font-extrabold text-lg text-[#232724]">
                    {totalPrice.toLocaleString('fa-IR')}
                  </span>
                  <span className="text-xs text-[#657062]">تومان</span>
                </div>
              </div>

              {/* Checkout Action */}
              <button
                onClick={handleCheckoutClick}
                className="w-full py-3 bg-[#2c3d28] hover:bg-[#384e33] text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <span>ادامه و ثبت نهایی سفارش</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
