import React from 'react';
import { ShoppingBag, Eye, Star, Check } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';

interface ProductCardProps {
  product: Product;
  onNavigate: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onNavigate }) => {
  const { addToCart } = useCart();
  const [justAdded, setJustAdded] = React.useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, product.sizes[0], 1);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1200);
  };

  const defaultSize = product.sizes[0];

  return (
    <div
      onClick={() => onNavigate(product.id)}
      className="group bg-white rounded-2xl border border-[#ebe5da] overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col justify-between cursor-pointer relative"
    >
      {/* Product Image & Badges */}
      <div className="relative aspect-square w-full bg-[#f4efe6] overflow-hidden">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 items-end">
          {product.badge && (
            <span className="bg-white/95 backdrop-blur-xs text-[#2e432b] text-[11px] font-semibold px-2.5 py-1 rounded-full shadow-xs border border-[#e3ded2]">
              {product.badge}
            </span>
          )}
          {product.isSeasonal && (
            <span className="bg-[#8b2332] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
              {product.seasonTag || 'نوبارانه فصل'}
            </span>
          )}
        </div>

        {/* Quick View Overlay on Hover */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
          <span className="bg-white/90 text-[#232724] text-xs font-semibold px-3 py-1.5 rounded-full flex items-center gap-1 shadow-sm">
            <Eye className="w-3.5 h-3.5" />
            مشاهده جزئیات
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 flex flex-col flex-1 justify-between gap-3 text-right">
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-[#757f72] mb-1">
            <span>{product.category}</span>
            <div className="flex items-center gap-1 text-[#b58728] font-medium">
              <span>{product.rating}</span>
              <Star className="w-3 h-3 fill-current" />
            </div>
          </div>

          {/* Product Name */}
          <h3 className="font-bold text-[#232724] text-base leading-snug group-hover:text-[#8b2332] transition-colors line-clamp-1">
            {product.name}
          </h3>

          {/* Size or Packaging description */}
          <p className="text-xs text-[#879084] mt-1 line-clamp-1">
            {defaultSize?.description || defaultSize?.label}
          </p>
        </div>

        {/* Price & Action Row */}
        <div className="pt-2 border-t border-[#f2ede4] flex items-center justify-between">
          <div className="flex flex-col text-right">
            <span className="text-[11px] text-[#8c948b]">بهای محصول:</span>
            <div className="flex items-center gap-1">
              <span className="font-extrabold text-[#232724] text-base">
                {defaultSize.price.toLocaleString('fa-IR')}
              </span>
              <span className="text-xs font-medium text-[#687065]">تومان</span>
            </div>
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={handleAddToCart}
            title="افزودن به سبد خرید"
            className={`p-2.5 rounded-xl border transition-all duration-200 flex items-center justify-center ${
              justAdded
                ? 'bg-[#3b5334] text-white border-[#3b5334]'
                : 'border-[#dfd8cc] bg-[#faf7f2] text-[#2e432b] hover:bg-[#2e432b] hover:text-white hover:border-[#2e432b]'
            }`}
          >
            {justAdded ? (
              <Check className="w-4 h-4 stroke-[2.5]" />
            ) : (
              <ShoppingBag className="w-4 h-4 stroke-[2]" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
