import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 44, showText = false }) => {
  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 160 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 transition-transform duration-300 group-hover:scale-105"
      >
        {/* Ground Line */}
        <path
          d="M16 150C48 147 112 147 144 150"
          stroke="#2A381E"
          strokeWidth="4"
          strokeLinecap="round"
        />

        {/* Floating herbal steam seeds/dots */}
        <circle cx="95" cy="48" r="3.5" fill="#3D4F28" />
        <circle cx="108" cy="38" r="2.8" fill="#3D4F28" />
        <circle cx="138" cy="54" r="3.5" fill="#3D4F28" />
        <circle cx="152" cy="28" r="3.2" fill="#3D4F28" />

        {/* Floating Green Leaves (Olive & Emerald) */}
        {/* Main large leaf */}
        <path
          d="M125 4C140 18 152 42 120 50C108 34 116 14 125 4Z"
          fill="#8CA358"
          stroke="#2A381E"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />
        {/* Leaf vein */}
        <path
          d="M124 8C127 22 130 36 122 47"
          stroke="#2A381E"
          strokeWidth="2.5"
          strokeLinecap="round"
        />

        {/* Small second leaf */}
        <path
          d="M140 22C148 30 156 46 138 52C130 42 135 28 140 22Z"
          fill="#6F883F"
          stroke="#2A381E"
          strokeWidth="3"
          strokeLinejoin="round"
        />

        {/* Pot Lid (Tilted/Ajar) */}
        <g transform="rotate(-8 80 32)">
          {/* Lid knob */}
          <path
            d="M74 18C74 13 86 13 86 18C86 21 82 24 80 24C78 24 74 21 74 18Z"
            fill="#8B2332"
            stroke="#2A381E"
            strokeWidth="3.5"
          />
          {/* Lid dome */}
          <path
            d="M48 42C48 32 62 23 80 23C98 23 112 32 112 42C95 44 65 44 48 42Z"
            fill="#B9A458"
            stroke="#2A381E"
            strokeWidth="4"
          />
          {/* Lid bottom rim */}
          <ellipse
            cx="80"
            cy="42"
            rx="32"
            ry="4.5"
            fill="#791C28"
            stroke="#2A381E"
            strokeWidth="3.5"
          />
        </g>

        {/* Pot Neck / Rim */}
        <path
          d="M44 56C56 61 104 61 116 56L124 70C108 76 52 76 36 70L44 56Z"
          fill="#8B2332"
          stroke="#2A381E"
          strokeWidth="4"
          strokeLinejoin="round"
        />
        {/* Upper rim highlight */}
        <ellipse
          cx="80"
          cy="56"
          rx="36"
          ry="5.5"
          fill="#A43343"
          stroke="#2A381E"
          strokeWidth="3.5"
        />

        {/* Pot Belly Main Shape */}
        <path
          d="M36 70C24 96 32 135 56 142C72 146 88 146 104 142C128 135 136 96 124 70C108 76 52 76 36 70Z"
          fill="#B5A152"
          stroke="#2A381E"
          strokeWidth="4.5"
          strokeLinejoin="round"
        />

        {/* Right Burgundy Glaze Patch */}
        <path
          d="M102 78C118 90 125 116 114 137C104 141 94 143 82 144C98 138 106 112 96 90C92 82 86 78 82 76C89 76 96 77 102 78Z"
          fill="#7F1D2B"
        />

        {/* Inner Ivory/Cream Body */}
        <path
          d="M48 76C38 96 42 126 62 134C74 138 88 137 98 132C86 136 72 135 60 128C48 118 46 95 56 78C62 76 54 75 48 76Z"
          fill="#FDF9ED"
        />

        {/* Center Cream Glaze Fill */}
        <path
          d="M58 80C48 98 52 122 70 128C88 128 98 114 96 95C94 82 84 76 74 76C68 76 62 78 58 80Z"
          fill="#F7F1DF"
          stroke="#2A381E"
          strokeWidth="3"
        />

        {/* Cream Highlight Specular Shine */}
        <ellipse
          cx="62"
          cy="98"
          rx="5"
          ry="14"
          transform="rotate(-18 62 98)"
          fill="#FFFFFF"
          fillOpacity="0.8"
        />
        <circle cx="68" cy="84" r="3" fill="#FFFFFF" fillOpacity="0.8" />
      </svg>

      {showText && (
        <div className="flex flex-col text-right leading-tight">
          <span className="font-extrabold text-xl text-[#2e2621] tracking-tight hover:text-[#882433] transition-colors">
            خوشمزه‌ها
          </span>
          <span className="text-[11px] font-medium text-[#656d62]">
            طعم اصیل خانگی و سنتی
          </span>
        </div>
      )}
    </div>
  );
};
