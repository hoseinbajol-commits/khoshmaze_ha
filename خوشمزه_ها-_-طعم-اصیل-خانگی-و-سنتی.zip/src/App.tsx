/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CartProvider, useCart } from './context/CartContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { CartDrawer } from './components/cart/CartDrawer';
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { SeasonalPage } from './pages/SeasonalPage';
import { PackagingPage } from './pages/PackagingPage';
import { ServicesPage } from './pages/ServicesPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { PageView } from './types';
import { Check, X } from 'lucide-react';

function MainApp() {
  const [currentPage, setCurrentPage] = useState<PageView>({ type: 'home' });
  const { toastMessage, dismissToast } = useCart();

  // Handle URL hash navigation or popstate
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  const renderCurrentPage = () => {
    switch (currentPage.type) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'products':
        return (
          <ProductsPage
            initialCategorySlug={currentPage.categorySlug}
            initialSeasonalOnly={currentPage.seasonalOnly}
            onNavigate={setCurrentPage}
          />
        );
      case 'categories':
        return <CategoriesPage onNavigate={setCurrentPage} />;
      case 'product-detail':
        return (
          <ProductDetailPage
            productId={currentPage.productId}
            onNavigate={setCurrentPage}
          />
        );
      case 'seasonal':
        return <SeasonalPage onNavigate={setCurrentPage} />;
      case 'packaging':
        return <PackagingPage onNavigate={setCurrentPage} />;
      case 'services':
        return <ServicesPage onNavigate={setCurrentPage} />;
      case 'about':
        return <AboutPage onNavigate={setCurrentPage} />;
      case 'contact':
        return <ContactPage onNavigate={setCurrentPage} />;
      case 'cart':
        return <CartPage onNavigate={setCurrentPage} />;
      case 'checkout':
        return <CheckoutPage onNavigate={setCurrentPage} />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#faf8f4] text-[#232724] font-['Vazirmatn',sans-serif] selection:bg-[#2c3d28] selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#2c3d28] text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 border border-[#3f573a] animate-in slide-in-from-bottom-5">
          <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <Check className="w-3.5 h-3.5 text-[#bfe8aa]" />
          </div>
          <span className="text-xs font-semibold">{toastMessage}</span>
          <button
            onClick={dismissToast}
            className="text-white/60 hover:text-white mr-1"
            aria-label="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Header */}
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />

      {/* Main Content Area */}
      <main className="flex-1">{renderCurrentPage()}</main>

      {/* Cart Sliding Drawer */}
      <CartDrawer onNavigate={setCurrentPage} />

      {/* Comprehensive Footer */}
      <Footer onNavigate={setCurrentPage} />
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <MainApp />
    </CartProvider>
  );
}
